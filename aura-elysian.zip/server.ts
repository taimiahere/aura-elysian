import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini client successfully initialized.");
  } catch (error) {
    console.error("Failed to initialize Gemini client:", error);
  }
} else {
  console.warn("GEMINI_API_KEY is not set or using placeholder. Running in fallback simulation mode.");
}

// In-Memory Database for persistent feel & real operations
const db = {
  leads: [
    { id: "1", name: "Alessandra Moretti", email: "alessandra@morettidesign.it", company: "Moretti Haute Couture", status: "Active Lead", value: "$45,000", service: "Elite Branding", date: "2026-06-15" },
    { id: "2", name: "Charlotte Dupond", email: "charlotte@maisondupond.fr", company: "Maison Dupond Perfumerie", status: "Proposal", value: "$62,000", service: "Full-Scale Launch", date: "2026-06-18" },
    { id: "3", name: "Genevieve Thorne", email: "g.thorne@thornedev.com", company: "Thorne Aesthetic Clinic", status: "Contract Signed", value: "$28,000", service: "CRM Automation", date: "2026-06-20" },
    { id: "4", name: "Saskia de Jong", email: "saskia@dejonggallery.nl", company: "De Jong Fine Arts", status: "Contacted", value: "$18,500", service: "Private Curator App", date: "2026-06-25" },
    { id: "5", name: "Penelope Cruz", email: "penelope@rosepetal.com", company: "Rose Petal Wellness", status: "Active Lead", value: "$35,000", service: "E-Commerce Luxury", date: "2026-06-28" }
  ],
  projects: [
    { id: "1", name: "Elysian Branding Rebirth", client: "Moretti Haute Couture", progress: 75, status: "In Progress", duedate: "2026-08-01", budget: "$45,000", lead: "Seraphina Rose" },
    { id: "2", name: "Maison Dupond Web Atelier", client: "Maison Dupond Perfumerie", progress: 40, status: "In Progress", duedate: "2026-09-15", budget: "$62,000", lead: "Giselle Moreau" },
    { id: "3", name: "Aesthetic CRM & Calendar Integration", client: "Thorne Aesthetic Clinic", progress: 100, status: "Completed", duedate: "2026-06-30", budget: "$28,000", lead: "Chantal Vance" }
  ],
  tasks: [
    { id: "1", projectId: "1", title: "Refine Silk Palette Typography", status: "Completed", priority: "High", assignee: "Seraphina Rose", dueDate: "2026-07-05" },
    { id: "2", projectId: "1", title: "Approve Glassmorphic Landing Layout", status: "In Progress", priority: "Medium", assignee: "Anouk Dubois", dueDate: "2026-07-10" },
    { id: "3", projectId: "2", title: "Maison Dupond Fragrance Quiz Architecture", status: "In Progress", priority: "High", assignee: "Giselle Moreau", dueDate: "2026-07-18" },
    { id: "4", projectId: "3", title: "Formulate Automated SMS Reminders", status: "Completed", priority: "Low", assignee: "Chantal Vance", dueDate: "2026-06-25" }
  ],
  invoices: [
    { id: "INV-2026-001", client: "Moretti Haute Couture", amount: "$22,500", status: "Paid", issued: "2026-06-01", due: "2026-06-15" },
    { id: "INV-2026-002", client: "Maison Dupond Perfumerie", amount: "$31,000", status: "Sent", issued: "2026-06-15", due: "2026-07-15" },
    { id: "INV-2026-003", client: "Thorne Aesthetic Clinic", amount: "$28,000", status: "Paid", issued: "2026-05-20", due: "2026-06-20" }
  ],
  messages: [
    { id: "1", sender: "Seraphina Rose", role: "Elite Strategist", content: "Good morning team! The Moretti Haute Couture branding palette is coming together beautifully. What do we think of the new Soft Amethyst tint?", time: "09:14 AM", avatar: "SR" },
    { id: "2", sender: "Anouk Dubois", role: "Creative Designer", content: "I absolutely adore it. It pairs gorgeously with our dark berry background. Let's showcase it in the proposal tomorrow.", time: "09:28 AM", avatar: "AD" },
    { id: "3", sender: "Giselle Moreau", role: "Product Designer", content: "Agreed. I am incorporating it into the Maison Dupond perfume packaging mockup as well.", time: "10:02 AM", avatar: "GM" }
  ],
  auditLogs: [
    { id: "1", user: "taimiahome@gmail.com", role: "Administrator", action: "User session authorized via Google OAuth", target: "Auth Service", timestamp: "2026-07-01 07:47:34" },
    { id: "2", user: "taimiahome@gmail.com", role: "Administrator", action: "Updated subscription tier to Elite Diamond Concierge", target: "Billing Engine", timestamp: "2026-07-01 07:49:10" },
    { id: "3", user: "taimiahome@gmail.com", role: "Administrator", action: "Created API Key 'AURA_LIVE_STRATEGY_PRODUCTION'", target: "Integrations Engine", timestamp: "2026-07-01 07:50:00" }
  ],
  apiKeys: [
    { id: "key_1", name: "Aura Live Strategy Engine", prefix: "aur_live_...", created: "2026-07-01", status: "Active", permissions: "Full Access" },
    { id: "key_2", name: "Elysian Client Concierge Webhook", prefix: "aur_web_...", created: "2026-06-15", status: "Active", permissions: "Read-Only" }
  ]
};

// --- API Routes ---

// Gemini AI Chat Agent
app.post("/api/ai/chat", async (req, res) => {
  const { message, history } = req.body;
  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  // Fallback response if Gemini isn't available
  const getFallbackResponse = (msg: string) => {
    const lowercase = msg.toLowerCase();
    if (lowercase.includes("marketing") || lowercase.includes("branding")) {
      return "Darlings, for a truly luxurious brand identity, we should steer clear of heavy, aggressive modern fonts and focus on hand-serifed letterforms coupled with rich, negative space and sophisticated dusty pastel hues. Try leaning into our Gradient Pink (#FF2D8D → #FF78C5) on a #130814 berry canvas. Shall we draft a social campaign outline with this style?";
    }
    if (lowercase.includes("invoice") || lowercase.includes("payment")) {
      return "Ah, billing is the art of transaction elegance! I have drafted a custom high-end client payment reminder emphasizing our signature glassmorphism invoices. You can send INV-2026-002 directly from the CRM tab. Would you like me to automate this?";
    }
    return `Welcome to the Aura Elysian luxury concierge! I have analyzed your creative business parameters. As your Senior AI brand Strategist, I recommend organizing your high-profile tasks into weekly aesthetic sprint boards. Let's elevate your boutique workflow. How else can I assist with your branding, client CRM, or strategy today?`;
  };

  if (!ai) {
    // Return a beautiful, simulated response matching the premium brand persona
    setTimeout(() => {
      return res.json({ text: getFallbackResponse(message) });
    }, 1000);
    return;
  }

  try {
    const systemInstruction = `You are "Aura Elysian AI Strategy & Design Concierge", a high-end, elite brand consultant, copywriter, and business operations advisor tailored exclusively for ultra-premium feminine brands, luxury aesthetic clinics, fine perfumeries, and creative agencies. 
- Tone: Highly sophisticated, professional, chic, articulate, encouraging, and visually minded. Use terms like "darlings", "elegance", "couture", "aesthetic", and "bespoke" naturally but maintain sharp, practical enterprise strategy.
- Knowledge: Expert in branding guidelines, luxury client relations (CRM), premium pricing tiers, and aesthetic spacing.
- Style: Respond with clear headings, bulleted lists, and exquisite styling suggestions. Always refer to the color palette when talking about design: Deep Berry (#130814), Rose Accent (#FF2D8D), and Soft Pink (#F7A8D7).`;

    // Construct the contents parameter incorporating chat history
    const contents: any[] = [];
    if (history && Array.isArray(history)) {
      history.slice(-6).forEach((h: any) => {
        contents.push({
          role: h.role === "user" ? "user" : "model",
          parts: [{ text: h.content }]
        });
      });
    }
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction,
        temperature: 0.85,
      }
    });

    return res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini Generation Error:", error);
    return res.status(500).json({ error: "Failed to communicate with Aura Strategy Engine. Fallback mode activated.", text: getFallbackResponse(message) });
  }
});

// CRM Leads CRUD
app.get("/api/crm/leads", (req, res) => {
  res.json(db.leads);
});

app.post("/api/crm/leads", (req, res) => {
  const { name, email, company, value, service, status } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: "Name and email are required." });
  }
  const newLead = {
    id: String(db.leads.length + 1),
    name,
    email,
    company: company || "Freelance Luxury Elite",
    status: status || "Active Lead",
    value: value || "$15,000",
    service: service || "Aesthetic Consulting",
    date: new Date().toISOString().split('T')[0]
  };
  db.leads.unshift(newLead);
  res.status(201).json(newLead);
});

// Projects CRUD
app.get("/api/projects", (req, res) => {
  res.json(db.projects);
});

app.post("/api/projects", (req, res) => {
  const { name, client, budget, lead, progress } = req.body;
  if (!name || !client) {
    return res.status(400).json({ error: "Project name and client are required." });
  }
  const newProject = {
    id: String(db.projects.length + 1),
    name,
    client,
    progress: progress ? Number(progress) : 0,
    status: "In Progress",
    duedate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    budget: budget || "$20,000",
    lead: lead || "Seraphina Rose"
  };
  db.projects.push(newProject);
  res.status(201).json(newProject);
});

// Tasks CRUD
app.get("/api/tasks", (req, res) => {
  res.json(db.tasks);
});

app.post("/api/tasks", (req, res) => {
  const { title, projectId, priority, assignee, dueDate } = req.body;
  if (!title) {
    return res.status(400).json({ error: "Task title is required." });
  }
  const newTask = {
    id: String(db.tasks.length + 1),
    projectId: projectId || "1",
    title,
    status: "In Progress",
    priority: priority || "Medium",
    assignee: assignee || "Seraphina Rose",
    dueDate: dueDate || new Date().toISOString().split('T')[0]
  };
  db.tasks.push(newTask);
  res.status(201).json(newTask);
});

// Toggle Task Status
app.put("/api/tasks/:id/toggle", (req, res) => {
  const task = db.tasks.find(t => t.id === req.params.id);
  if (!task) return res.status(404).json({ error: "Task not found" });
  task.status = task.status === "Completed" ? "In Progress" : "Completed";
  res.json(task);
});

// Invoices CRUD
app.get("/api/invoices", (req, res) => {
  res.json(db.invoices);
});

app.post("/api/invoices", (req, res) => {
  const { client, amount, status } = req.body;
  const newInvoice = {
    id: `INV-2026-00${db.invoices.length + 1}`,
    client: client || "Bespoke Patron",
    amount: amount || "$5,000",
    status: status || "Sent",
    issued: new Date().toISOString().split('T')[0],
    due: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  };
  db.invoices.unshift(newInvoice);
  res.status(201).json(newInvoice);
});

// Messages List
app.get("/api/messages", (req, res) => {
  res.json(db.messages);
});

app.post("/api/messages", (req, res) => {
  const { sender, role, content, avatar } = req.body;
  if (!content) return res.status(400).json({ error: "Content is required" });
  const newMsg = {
    id: String(db.messages.length + 1),
    sender: sender || "Elite Administrator",
    role: role || "Manager",
    content,
    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    avatar: avatar || "EA"
  };
  db.messages.push(newMsg);
  res.status(201).json(newMsg);
});

// API Keys List & CRUD
app.get("/api/api-keys", (req, res) => {
  res.json(db.apiKeys);
});

app.post("/api/api-keys", (req, res) => {
  const { name, permissions } = req.body;
  if (!name) return res.status(400).json({ error: "Key name is required" });
  const newKey = {
    id: `key_${db.apiKeys.length + 1}`,
    name,
    prefix: `aur_${Math.random().toString(36).substring(2, 5)}_...`,
    created: new Date().toISOString().split('T')[0],
    status: "Active",
    permissions: permissions || "Full Access"
  };
  db.apiKeys.push(newKey);
  res.status(201).json(newKey);
});

// Audit Logs
app.get("/api/audit-logs", (req, res) => {
  res.json(db.auditLogs);
});

// --- Vite & Frontend Ingress Setup ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite dev middleware loaded.");
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("Serving production build from dist.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Luxury full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Critical error starting Express + Vite server:", err);
});
