export type UserRole = "Administrator" | "Elite User" | "Guest Patron";

export interface UserProfile {
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  company: string;
  tier: "Standard Silver" | "Luxe Gold" | "Elite Diamond Concierge";
  joinedDate: string;
}

export interface Lead {
  id: string;
  name: string;
  email: string;
  company: string;
  status: string;
  value: string;
  service: string;
  date: string;
}

export interface Project {
  id: string;
  name: string;
  client: string;
  progress: number;
  status: "In Progress" | "Completed" | "On Hold";
  duedate: string;
  budget: string;
  lead: string;
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  status: "In Progress" | "Completed";
  priority: "High" | "Medium" | "Low";
  assignee: string;
  dueDate: string;
}

export interface Invoice {
  id: string;
  client: string;
  amount: string;
  status: "Paid" | "Sent" | "Overdue";
  issued: string;
  due: string;
}

export interface PaymentRecord {
  id: string;
  invoiceId: string;
  client: string;
  amount: string;
  status: "Success" | "Pending";
  date: string;
  method: string;
}

export interface Message {
  id: string;
  sender: string;
  role: string;
  content: string;
  time: string;
  avatar: string;
}

export interface AuditLog {
  id: string;
  user: string;
  role: string;
  action: string;
  target: string;
  timestamp: string;
}

export interface ApiKey {
  id: string;
  name: string;
  prefix: string;
  created: string;
  status: "Active" | "Revoked";
  permissions: string;
}

// Routes Definition
export type MainView = "landing" | "login" | "signup" | "forgot-password" | "verify" | "dashboard" | "admin" | "maintenance" | "not-found";

export type DashboardSubView = 
  | "analytics" 
  | "reports" 
  | "projects" 
  | "tasks" 
  | "calendar" 
  | "ai-assistant" 
  | "crm" 
  | "invoices" 
  | "payments" 
  | "billing" 
  | "messages" 
  | "notifications" 
  | "documents" 
  | "team" 
  | "profile" 
  | "settings"
  | "api-keys"
  | "integrations"
  | "help-center";

export type AdminSubView = "admin-analytics" | "users" | "roles" | "audit-logs";
