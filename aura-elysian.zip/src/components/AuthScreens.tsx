import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Sparkles, Mail, Lock, User, Compass, ArrowLeft, Eye, EyeOff, ShieldCheck } from "lucide-react";
import { motion } from "motion/react";

export const AuthScreens: React.FC = () => {
  const { 
    currentView, setView, login, signup, triggerOAuth, addToast 
  } = useApp();

  // Common inputs
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Forgot password inputs
  const [forgotEmail, setForgotEmail] = useState("");
  
  // Verification code inputs
  const [verificationCode, setVerificationCode] = useState(["", "", "", "", "", ""]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const ok = await login(email, password);
    if (!ok) setIsSubmitting(false);
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const ok = await signup(name, email, password);
    if (!ok) setIsSubmitting(false);
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setIsSubmitting(true);
    setTimeout(() => {
      addToast(`An exquisite password recovery charter has been dispatched to ${forgotEmail}.`, "info");
      setView("login");
      setIsSubmitting(false);
    }, 1000);
  };

  const handleVerifySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      // Automatically log in user as standard user after successful mock verification
      addToast("Account verified elegantly! Welcome to your creative workspace.", "success");
      login("elite.creative@auraelysian.com", "any-password");
      setIsSubmitting(false);
    }, 1200);
  };

  const handleCodeChange = (idx: number, val: string) => {
    if (val.length > 1) return;
    const nextCode = [...verificationCode];
    nextCode[idx] = val;
    setVerificationCode(nextCode);

    // Auto focus next input
    if (val && idx < 5) {
      const nextInput = document.getElementById(`verify-code-input-${idx + 1}`);
      nextInput?.focus();
    }
  };

  const renderBackgroundGlows = () => (
    <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
      <div className="absolute top-[20%] left-[20%] w-[50%] h-[50%] bg-[#FF2D8D]/10 blur-[130px] rounded-full" />
      <div className="absolute bottom-[20%] right-[20%] w-[40%] h-[45%] bg-[#FF78C5]/10 blur-[150px] rounded-full" />
    </div>
  );

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: "easeOut" } }
  };

  // --- LOGIN VIEW ---
  if (currentView === "login") {
    return (
      <div className="min-h-screen bg-[#130814] flex items-center justify-center p-6 relative" id="auth-screen-login-root">
        {renderBackgroundGlows()}
        
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          className="w-full max-w-md bg-[#2A1830]/90 backdrop-blur-2xl border border-[#5C2A50] rounded-3xl p-8 shadow-[0_20px_50px_rgba(0,0,0,0.6)] text-left relative z-10"
        >
          {/* Logo */}
          <div className="text-center space-y-2 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center mx-auto shadow-[0_0_15px_rgba(255,45,141,0.5)]">
              <Sparkles className="text-white" size={22} />
            </div>
            <h2 className="text-2xl font-bold text-white tracking-wide uppercase font-sans">Maison Sign-In</h2>
            <p className="text-xs text-[#D8B7CC]">Darlings, enter your sovereign credentials to enter.</p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-semibold">Your Secure Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#D8B7CC]/50" size={16} />
                <input 
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. taimiahome@gmail.com"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl pl-11 pr-4 py-3 text-xs text-white placeholder-[#D8B7CC]/30 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.15)]"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-semibold">Your Confidential Key</label>
                <button 
                  type="button"
                  onClick={() => setView("forgot-password")}
                  className="text-[10px] font-bold text-[#FF5FA8] hover:text-white transition-colors cursor-pointer uppercase font-mono"
                >
                  Forgot passcode?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#D8B7CC]/50" size={16} />
                <input 
                  type={showPassword ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your security credentials..."
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl pl-11 pr-11 py-3 text-xs text-white placeholder-[#D8B7CC]/30 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.15)]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#D8B7CC]/60 hover:text-white"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 mt-2 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(255,45,141,0.3)] hover:shadow-[0_0_25px_rgba(255,45,141,0.5)] cursor-pointer hover:scale-[1.01] transition-all"
              id="login-form-submit"
            >
              {isSubmitting ? "Authorizing Suite..." : "Sign In with Elegance"}
            </button>
          </form>

            <div className="relative my-6 text-center">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-[#4B2342]/60"></div></div>
              <span className="relative bg-[#2A1830] px-4 text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]/50">Or Secure Access Via</span>
            </div>

            {/* Google Login fully functional simulation */}
            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={() => triggerOAuth("google")}
                className="flex items-center justify-center gap-2 px-4 py-3 bg-[#130814] border border-[#4B2342] hover:border-[#FF2D8D] hover:bg-[#311B37]/30 text-white rounded-xl text-xs font-medium cursor-pointer transition-all"
                id="oauth-google-btn"
              >
                {/* SVG Google */}
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#EA4335" d="M12.24 10.285V14.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.859-3.578-7.859-8s3.53-8 7.859-8c2.46 0 4.105 1.025 5.047 1.926l3.227-3.107C18.281 1.094 15.566 0 12.24 0 5.58 0 .18 5.37.18 12s5.4 12 12.06 12c6.94 0 11.55-4.88 11.55-11.75 0-.79-.085-1.393-.19-1.965H12.24z" />
                </svg>
                <span>Google</span>
              </button>

              <button 
                onClick={() => triggerOAuth("github")}
                className="flex items-center justify-center gap-2 px-4 py-3 bg-[#130814] border border-[#4B2342] hover:border-[#FF2D8D] hover:bg-[#311B37]/30 text-white rounded-xl text-xs font-medium cursor-pointer transition-all"
              >
                {/* GitHub Logo */}
                <svg className="w-4 h-4 fill-white" viewBox="0 0 24 24">
                  <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/>
                </svg>
                <span>GitHub</span>
              </button>
            </div>

          <div className="mt-8 text-center">
            <span className="text-xs text-[#D8B7CC]">
              First time visiting, darlings?{" "}
              <button 
                onClick={() => setView("signup")}
                className="font-bold text-[#FF5FA8] hover:text-white transition-colors cursor-pointer"
              >
                Apply for suite access
              </button>
            </span>
          </div>

          <button 
            onClick={() => setView("landing")}
            className="mt-6 flex items-center justify-center gap-2 mx-auto text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]/60 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft size={12} />
            <span>Return to Landing</span>
          </button>
        </motion.div>
      </div>
    );
  }

  // --- SIGNUP VIEW ---
  if (currentView === "signup") {
    return (
      <div className="min-h-screen bg-[#130814] flex items-center justify-center p-6 relative" id="auth-screen-signup-root">
        {renderBackgroundGlows()}
        
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          className="w-full max-w-md bg-[#2A1830]/90 backdrop-blur-2xl border border-[#5C2A50] rounded-3xl p-8 shadow-[0_20px_50px_rgba(0,0,0,0.6)] text-left relative z-10"
        >
          <div className="text-center space-y-2 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center mx-auto shadow-[0_0_15px_rgba(255,45,141,0.5)]">
              <Compass className="text-white animate-spin" size={22} style={{ animationDuration: '10s' }} />
            </div>
            <h2 className="text-2xl font-bold text-white tracking-wide uppercase font-sans">Apply for Membership</h2>
            <p className="text-xs text-[#D8B7CC]">Darlings, register your boutique brand for private cloud access.</p>
          </div>

          <form onSubmit={handleSignupSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-semibold">Noble Brand Owner Name</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-[#D8B7CC]/50" size={16} />
                <input 
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Penelope Cruz"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl pl-11 pr-4 py-3 text-xs text-white placeholder-[#D8B7CC]/30 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.15)]"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-semibold">Your Business Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#D8B7CC]/50" size={16} />
                <input 
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. penelope@rosepetal.com"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl pl-11 pr-4 py-3 text-xs text-white placeholder-[#D8B7CC]/30 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.15)]"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-semibold">Create Confidential Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#D8B7CC]/50" size={16} />
                <input 
                  type={showPassword ? "text" : "password"}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create high-security key..."
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl pl-11 pr-11 py-3 text-xs text-white placeholder-[#D8B7CC]/30 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.15)]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#D8B7CC]/60 hover:text-white"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div className="flex items-start gap-2.5 pt-1">
              <input type="checkbox" required className="accent-[#FF2D8D] mt-1 cursor-pointer rounded" id="auth-signup-check" />
              <label htmlFor="auth-signup-check" className="text-[10px] leading-relaxed text-[#D8B7CC] cursor-pointer">
                I hereby request to initiate a luxury brand operations workspace. I acknowledge Aura’s strict privacy charter.
              </label>
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 mt-2 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(255,45,141,0.3)] hover:shadow-[0_0_25px_rgba(255,45,141,0.5)] cursor-pointer transition-all"
              id="signup-form-submit"
            >
              {isSubmitting ? "Dispatching Request..." : "Request Sovereign Workspace"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <span className="text-xs text-[#D8B7CC]">
              Already an honored member?{" "}
              <button 
                onClick={() => setView("login")}
                className="font-bold text-[#FF5FA8] hover:text-white transition-colors cursor-pointer"
              >
                Sign in here darlings
              </button>
            </span>
          </div>

          <button 
            onClick={() => setView("landing")}
            className="mt-6 flex items-center justify-center gap-2 mx-auto text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]/60 hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft size={12} />
            <span>Return to Landing</span>
          </button>
        </motion.div>
      </div>
    );
  }

  // --- FORGOT PASSWORD VIEW ---
  if (currentView === "forgot-password") {
    return (
      <div className="min-h-screen bg-[#130814] flex items-center justify-center p-6 relative" id="auth-screen-forgot-root">
        {renderBackgroundGlows()}
        
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          className="w-full max-w-md bg-[#2A1830]/90 backdrop-blur-2xl border border-[#5C2A50] rounded-3xl p-8 shadow-[0_20px_50px_rgba(0,0,0,0.6)] text-left relative z-10"
        >
          <div className="text-center space-y-2 mb-8">
            <h2 className="text-2xl font-bold text-white tracking-wide uppercase font-sans">Passcode Charter</h2>
            <p className="text-xs text-[#D8B7CC]">Darlings, enter your email. We will dispatch a recovery token swiftly.</p>
          </div>

          <form onSubmit={handleForgotSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-semibold">Your Registered Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-[#D8B7CC]/50" size={16} />
                <input 
                  type="email"
                  required
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="e.g. charlotte@maisondupond.fr"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl pl-11 pr-4 py-3 text-xs text-white placeholder-[#D8B7CC]/30 outline-none transition-all"
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 mt-2 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(255,45,141,0.3)] hover:scale-[1.01] transition-all cursor-pointer"
            >
              {isSubmitting ? "Transmitting Charter..." : "Dispatch Recovery Link"}
            </button>
          </form>

          <button 
            onClick={() => setView("login")}
            className="mt-8 flex items-center justify-center gap-2 mx-auto text-[10px] font-mono uppercase tracking-widest text-[#FF5FA8] hover:text-white transition-colors cursor-pointer"
          >
            <ArrowLeft size={12} />
            <span>Return to Sign In</span>
          </button>
        </motion.div>
      </div>
    );
  }

  // --- EMAIL VERIFICATION VIEW ---
  if (currentView === "verify") {
    return (
      <div className="min-h-screen bg-[#130814] flex items-center justify-center p-6 relative" id="auth-screen-verify-root">
        {renderBackgroundGlows()}
        
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          className="w-full max-w-md bg-[#2A1830]/90 backdrop-blur-2xl border border-[#5C2A50] rounded-3xl p-8 shadow-[0_20px_50px_rgba(0,0,0,0.6)] text-left relative z-10"
        >
          <div className="text-center space-y-2 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#FF2D8D]/20 to-[#FF78C5]/20 border border-[#FF2D8D] flex items-center justify-center mx-auto shadow-[0_0_15px_rgba(255,45,141,0.3)]">
              <ShieldCheck className="text-[#FF2D8D]" size={22} />
            </div>
            <h2 className="text-2xl font-bold text-white tracking-wide uppercase font-sans">Verify Access</h2>
            <p className="text-xs text-[#D8B7CC]">Darlings, enter the 6-digit credential code dispatched to your mailbox.</p>
          </div>

          <form onSubmit={handleVerifySubmit} className="space-y-6">
            <div className="flex justify-between gap-2" id="verify-code-fields-container">
              {verificationCode.map((char, idx) => (
                <input 
                  key={idx}
                  id={`verify-code-input-${idx}`}
                  type="text"
                  maxLength={1}
                  required
                  value={char}
                  onChange={(e) => handleCodeChange(idx, e.target.value)}
                  className="w-12 h-14 bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl text-center text-lg font-bold text-white outline-none transition-all focus:shadow-[0_0_12px_rgba(255,45,141,0.3)]"
                />
              ))}
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(255,45,141,0.3)] hover:shadow-[0_0_25px_rgba(255,45,141,0.5)] transition-all cursor-pointer"
            >
              {isSubmitting ? "Verifying..." : "Verify & Initialize Suite"}
            </button>
          </form>

          <div className="mt-6 text-center text-xs text-[#D8B7CC] space-y-4">
            <p>
              Didn't receive code darlings?{" "}
              <button 
                type="button"
                onClick={() => addToast("Code re-dispatched to your noble mailbox.")}
                className="font-bold text-[#FF5FA8] hover:text-white transition-colors"
              >
                Resend verification Code
              </button>
            </p>
            <button 
              onClick={() => setView("signup")}
              className="flex items-center justify-center gap-2 mx-auto text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]/60 hover:text-white transition-colors cursor-pointer"
            >
              <ArrowLeft size={12} />
              <span>Change Application parameters</span>
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return null;
};
