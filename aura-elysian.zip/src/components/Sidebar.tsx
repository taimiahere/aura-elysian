import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { DashboardSubView, MainView } from "../types";
import { 
  motion 
} from "motion/react";
import { 
  Sparkles, LayoutDashboard, Briefcase, CheckSquare, Calendar, Bot, Users, 
  Receipt, CreditCard, MessageSquare, Shield, Key, HelpCircle, 
  User, Settings, LogOut, ChevronLeft, ChevronRight, FileText, Bell, Layers, Database
} from "lucide-react";

export const Sidebar: React.FC = () => {
  const { 
    currentUser, activeDashboardTab, currentView, setDashboardTab, setView, logout 
  } = useApp();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const menuItems = [
    { id: "analytics", label: "Analytics", icon: LayoutDashboard },
    { id: "ai-assistant", label: "Aura AI Advisor", icon: Bot, isPremium: true },
    { id: "projects", label: "Projects", icon: Briefcase },
    { id: "tasks", label: "Tasks", icon: CheckSquare },
    { id: "calendar", label: "Calendar", icon: Calendar },
    { id: "crm", label: "CRM Leads", icon: Users },
    { id: "invoices", label: "Invoices", icon: Receipt },
    { id: "payments", label: "Payments", icon: CreditCard },
    { id: "messages", label: "Luxe Chat", icon: MessageSquare },
    { id: "documents", label: "Documents", icon: FileText },
    { id: "team", label: "Team", icon: Sparkles },
    { id: "help-center", label: "Help Center", icon: HelpCircle },
    { id: "profile", label: "Profile", icon: User },
    { id: "settings", label: "Settings", icon: Settings },
  ] as { id: DashboardSubView; label: string; icon: any; isPremium?: boolean }[];

  const isActive = (id: DashboardSubView) => activeDashboardTab === id && currentView === "dashboard";

  return (
    <motion.div 
      animate={{ width: isCollapsed ? "80px" : "280px" }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className="h-screen bg-[#190C1D]/60 backdrop-blur-2xl border-r border-[#4B2342] flex flex-col justify-between relative z-20 shrink-0 shadow-2xl"
      id="sidebar-container"
    >
      {/* Collapse Trigger Button */}
      <button 
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute top-6 -right-3.5 bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white p-1 rounded-full shadow-[0_0_15px_rgba(255,45,141,0.4)] border border-[#4B2342] hover:scale-110 transition-transform cursor-pointer"
        id="sidebar-toggle-btn"
      >
        {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
      </button>

      {/* Header Logo */}
      <div className="p-6 flex items-center gap-3 border-b border-[#4B2342]">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center shadow-[0_0_20px_rgba(255,45,141,0.3)] animate-pulse shrink-0">
          <Sparkles className="text-white" size={20} />
        </div>
        {!isCollapsed && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col text-left"
          >
            <span className="font-serif font-semibold tracking-tight text-white text-lg bg-gradient-to-r from-[#FFFFFF] to-[#F5DCEB] bg-clip-text text-transparent">LuxeAI</span>
            <span className="text-[10px] uppercase tracking-widest text-[#D8B7CC] font-mono">Aura Elysian</span>
          </motion.div>
        )}
      </div>

      {/* Main Navigation Scrollable */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-1.5 scrollbar-thin scrollbar-thumb-[#4B2342]">
        <div className="text-[10px] uppercase font-mono tracking-widest text-[#D8B7CC] opacity-60 mb-3 px-3">
          {isCollapsed ? "Core" : "Operational Core"}
        </div>
        
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => {
                setView("dashboard");
                setDashboardTab(item.id);
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer relative group ${
                isActive(item.id) 
                  ? "bg-[#2A1830] text-white border border-[#5C2A50]/40 shadow-inner"
                  : "text-[#D8B7CC] hover:bg-[#2A1830]/40 hover:text-white"
              }`}
              id={`sidebar-item-${item.id}`}
            >
              {isActive(item.id) && (
                <span className="w-2 h-2 bg-[#FF2D8D] rounded-full shrink-0" />
              )}
              <Icon size={18} className={isActive(item.id) ? "text-white" : "text-[#D8B7CC] group-hover:text-[#FF78C5] transition-colors"} />
              {!isCollapsed && (
                <span className="font-medium text-sm text-left flex-1 flex items-center justify-between">
                  {item.label}
                  {item.isPremium && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white shadow-[0_0_8px_rgba(255,45,141,0.3)] uppercase tracking-wide">
                      AI
                    </span>
                  )}
                </span>
              )}
            </button>
          );
        })}

        {/* Administrator Access Tier */}
        {currentUser?.role === "Administrator" && (
          <div className="pt-6">
            <div className="text-[10px] uppercase font-mono tracking-widest text-[#D8B7CC] opacity-60 mb-3 px-3">
              {isCollapsed ? "Admin" : "Admin Dashboard"}
            </div>
            <button
              onClick={() => setView("admin")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer relative group ${
                currentView === "admin" 
                  ? "bg-[#2A1830] text-white border border-[#5C2A50]/40 shadow-inner"
                  : "text-[#D8B7CC] hover:bg-[#2A1830]/40 hover:text-white"
              }`}
              id="sidebar-item-admin"
            >
              {currentView === "admin" && (
                <span className="w-2 h-2 bg-[#FF2D8D] rounded-full shrink-0" />
              )}
              <Database size={18} className={currentView === "admin" ? "text-white" : "text-[#D8B7CC] group-hover:text-[#FF78C5] transition-colors"} />
              {!isCollapsed && <span className="font-medium text-sm text-left flex-1">Security & Audit</span>}
            </button>
          </div>
        )}
      </div>

      {/* User Footer Profile Card */}
      <div className="p-4 border-t border-[#4B2342] bg-[#190C1D]/40 backdrop-blur-lg">
        {!isCollapsed ? (
          <div className="flex items-center justify-between gap-2 bg-[#311B37]/40 backdrop-blur-lg border border-[#5C2A50]/40 p-2.5 rounded-2xl shadow-inner">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center font-bold text-sm text-white border border-[#5C2A50] shrink-0">
                {currentUser?.avatar || "TA"}
              </div>
              <div className="flex flex-col min-w-0 text-left">
                <span className="text-white text-xs font-semibold truncate leading-tight">
                  {currentUser?.name || "Taimi A."}
                </span>
                <span className="text-[9px] text-[#D8B7CC] truncate leading-none">
                  {currentUser?.email || "taimiahome@gmail.com"}
                </span>
              </div>
            </div>
            <button 
              onClick={logout}
              className="text-[#D8B7CC] hover:text-[#FF2D8D] transition-colors p-1.5 hover:bg-[#311B37] rounded-lg cursor-pointer shrink-0"
              title="Logout"
              id="sidebar-logout-btn"
            >
              <LogOut size={16} />
            </button>
          </div>
        ) : (
          <div className="flex justify-center">
            <button 
              onClick={logout}
              className="w-10 h-10 rounded-xl bg-[#2A1830]/60 border border-[#4B2342] flex items-center justify-center text-[#D8B7CC] hover:text-[#FF2D8D] hover:bg-[#311B37] transition-all cursor-pointer"
              title="Logout"
              id="sidebar-logout-collapsed"
            >
              <LogOut size={16} />
            </button>
          </div>
        )}
      </div>
    </motion.div>
  );
};
