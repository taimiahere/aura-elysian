import React from "react";
import { useApp } from "../context/AppContext";
import { AnalyticsTab } from "./dashboard/AnalyticsTab";
import { ProjectsTasksTab } from "./dashboard/ProjectsTasksTab";
import { AiAssistantTab } from "./dashboard/AiAssistantTab";
import { CrmBillingTab } from "./dashboard/CrmBillingTab";
import { 
  CalendarTab, MessagesTab, DocumentsTab, TeamTab, ProfileTab, SettingsTab 
} from "./dashboard/GeneralTabs";
import { motion, AnimatePresence } from "motion/react";

export const DashboardContent: React.FC = () => {
  const { currentView } = useApp();

  const renderActiveTab = () => {
    switch (currentView) {
      case "dashboard":
      case "analytics":
        return <AnalyticsTab />;
      
      case "projects":
      case "tasks":
        return <ProjectsTasksTab />;
      
      case "ai-assistant":
        return <AiAssistantTab />;
      
      case "crm":
      case "customers":
      case "invoices":
      case "payments":
      case "billing":
      case "subscription":
        return <CrmBillingTab />;
      
      case "calendar":
        return <CalendarTab />;
      
      case "messages":
        return <MessagesTab />;
      
      case "documents":
        return <DocumentsTab />;
      
      case "team":
        return <TeamTab />;
      
      case "profile":
        return <ProfileTab />;
      
      case "settings":
      case "security":
      case "api-keys":
      case "integrations":
        return <SettingsTab />;
      
      default:
        return (
          <div className="text-center py-20 text-white font-mono space-y-4">
            <h2 className="text-xl font-bold">Aesthetic Under Construction</h2>
            <p className="text-xs text-[#D8B7CC]">This suite module is getting trimmed by Aura craftsmen.</p>
          </div>
        );
    }
  };

  return (
    <div className="flex-1 w-full relative z-10" id="dashboard-content-router">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentView}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.35, ease: "easeOut" }}
          className="w-full"
        >
          {renderActiveTab()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
