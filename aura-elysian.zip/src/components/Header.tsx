import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Sparkles, Bell, Globe, ChevronRight, CheckCircle, Menu, User, Calendar } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export const Header: React.FC = () => {
  const { 
    currentUser, currentView, activeDashboardTab, activeAdminTab, 
    notifications, markNotificationsAsRead, setDashboardTab, setView, addToast 
  } = useApp();
  const [showNotifications, setShowNotifications] = useState(false);

  const getBreadcrumbs = () => {
    const sequence = ["Portal"];
    if (currentView === "dashboard") {
      sequence.push("Dashboard");
      // Format active dashboard view name
      const name = activeDashboardTab.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
      sequence.push(name);
    } else if (currentView === "admin") {
      sequence.push("Security Suite");
      const name = activeAdminTab.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
      sequence.push(name);
    } else if (currentView === "landing") {
      sequence.push("Aura Elysian");
    }
    return sequence;
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header 
      className="bg-[#190C1D]/60 backdrop-blur-2xl border-b border-[#4B2342] h-20 px-8 flex items-center justify-between sticky top-0 z-30 shadow-[0_4px_30px_rgba(25,12,29,0.3)]"
      id="main-app-header"
    >
      {/* Left: Breadcrumbs & Dynamic Route */}
      <div className="flex items-center gap-3">
        {getBreadcrumbs().map((crumb, idx, arr) => (
          <React.Fragment key={crumb}>
            <span 
              className={`text-xs font-semibold uppercase tracking-widest font-mono ${
                idx === arr.length - 1 ? "text-[#FF5FA8] drop-shadow-[0_0_8px_rgba(255,45,141,0.2)]" : "text-[#D8B7CC]/60"
              }`}
            >
              {crumb}
            </span>
            {idx < arr.length - 1 && <ChevronRight size={12} className="text-[#4B2342]" />}
          </React.Fragment>
        ))}
      </div>

      {/* Right: Digital Clock, Tier Display & Notifications Dropdown */}
      <div className="flex items-center gap-6">
        
        {/* UTC Time Display with styling */}
        <div className="hidden md:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#2A1830]/50 backdrop-blur-md border border-[#4B2342] text-[#F5DCEB] text-xs font-mono shadow-inner">
          <Calendar size={13} className="text-[#FF2D8D]" />
          <span>2026-07-01 07:47:34 UTC</span>
        </div>

        {/* User Diamond Tier Badge */}
        {currentUser && (
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-[#FF2D8D]/20 to-[#FF78C5]/20 border border-[#FF2D8D]/50 text-white text-[10px] uppercase font-bold tracking-widest shadow-[0_0_12px_rgba(255,45,141,0.2)]">
            <Sparkles size={11} className="text-[#FF78C5]" />
            <span>{currentUser.tier}</span>
          </div>
        )}

        {/* Notifications Icon with Glow */}
        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className="w-10 h-10 rounded-xl bg-[#2A1830] border border-[#4B2342] flex items-center justify-center text-[#D8B7CC] hover:text-white hover:border-[#FF2D8D] hover:shadow-[0_0_12px_rgba(255,45,141,0.2)] transition-all cursor-pointer relative"
            id="header-notifications-bell"
          >
            <Bell size={18} />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-[10px] font-bold text-white flex items-center justify-center border border-[#190C1D] shadow-[0_0_8px_rgba(255,45,141,0.6)]">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Luxury Dropdown */}
          <AnimatePresence>
            {showNotifications && (
              <motion.div 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 15 }}
                transition={{ duration: 0.2 }}
                className="absolute right-0 mt-3 w-80 bg-[#2A1830]/85 backdrop-blur-xl border border-[#5C2A50] rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.6)] p-4 text-left z-50 overflow-hidden"
                id="header-notifications-dropdown"
              >
                <div className="flex items-center justify-between pb-3 border-b border-[#4B2342] mb-3">
                  <span className="text-white text-xs font-bold uppercase tracking-wider font-sans">Elysian Alerts</span>
                  {unreadCount > 0 && (
                    <button 
                      onClick={() => {
                        markNotificationsAsRead();
                        setShowNotifications(false);
                      }}
                      className="text-[10px] font-semibold text-[#FF5FA8] hover:text-white transition-colors cursor-pointer"
                    >
                      Mark all read
                    </button>
                  )}
                </div>

                <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                  {notifications.map((notif) => (
                    <div 
                      key={notif.id}
                      className={`p-2.5 rounded-xl border transition-all ${
                        notif.read ? "bg-[#2A1830]/20 border-transparent" : "bg-[#311B37]/60 border-[#4B2342]"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-1">
                        <span className="text-white font-semibold text-xs">{notif.title}</span>
                        <span className="text-[9px] text-[#D8B7CC] opacity-60 shrink-0">{notif.date}</span>
                      </div>
                      <p className="text-[11px] text-[#D8B7CC] mt-1 leading-relaxed">{notif.desc}</p>
                    </div>
                  ))}
                  {notifications.length === 0 && (
                    <div className="text-center py-4 text-xs text-[#D8B7CC]/60 font-mono">
                      No notifications, darlings.
                    </div>
                  )}
                </div>

                <div className="mt-3 pt-3 border-t border-[#4B2342] text-center">
                  <button 
                    onClick={() => {
                      setDashboardTab("profile");
                      setView("dashboard");
                      setShowNotifications(false);
                      addToast("Reviewing active concierge account security.");
                    }}
                    className="text-[10px] font-bold tracking-wider text-white hover:text-[#FF5FA8] transition-colors uppercase font-mono"
                  >
                    View Account Details
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Mini profile widget */}
        <button 
          onClick={() => {
            setView("dashboard");
            setDashboardTab("profile");
          }}
          className="flex items-center gap-2.5 hover:scale-105 transition-transform text-left cursor-pointer"
        >
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center font-bold text-sm text-white border border-[#FF2D8D]/40 shadow-[0_0_12px_rgba(255,45,141,0.3)]">
            {currentUser?.avatar || "TA"}
          </div>
          <div className="hidden sm:flex flex-col">
            <span className="text-white text-xs font-semibold leading-tight">{currentUser?.name || "Taimi A."}</span>
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#FF5FA8] leading-none">
              {currentUser?.role || "Administrator"}
            </span>
          </div>
        </button>

      </div>
    </header>
  );
};
