import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { 
  Sparkles, ShieldCheck, Zap, Heart, Star, Compass, DollarSign, Send, 
  ChevronRight, Play, Check, HelpCircle, Activity, Globe, MessageCircle 
} from "lucide-react";
import { motion } from "motion/react";

export const LandingPage: React.FC = () => {
  const { setView, addToast } = useApp();
  
  // Contact state
  const [contactForm, setContactForm] = useState({ name: "", email: "", agency: "", message: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email) {
      addToast("Darlings, please fill out your name and email so we can reach you.", "error");
      return;
    }
    setIsSubmitting(true);
    setTimeout(() => {
      addToast("Bespoke inquiry sent! An Elysian Concierge will contact you within 24 hours.", "success");
      setContactForm({ name: "", email: "", agency: "", message: "" });
      setIsSubmitting(false);
    }, 1200);
  };

  const pricingTiers = [
    {
      name: "Standard Silver",
      price: "$199",
      desc: "For emerging designers, boutiques, and high-end freelancers seeking structured operations.",
      features: [
        "Interactive Glassmorphic CRM Suite",
        "Classic Invoice & Billing Automations",
        "Bespoke Calendar & 10 Projects",
        "Aura AI Strategy - Standard Concierge",
        "Secure SSL Encryption",
      ],
      cta: "Initiate Suite",
      badge: "Introductory"
    },
    {
      name: "Luxe Gold",
      price: "$499",
      desc: "For thriving creative agencies, premium clinics, and luxury collectives seeking elite growth.",
      features: [
        "Everything in Silver, plus:",
        "Unlimited Bespoke Projects & Tasks",
        "Aura AI Strategy - Enhanced Reasoning",
        "Custom API Integrations & Webhooks",
        "Bespoke Invoicing with Stripe Integration",
        "Dedicated Creative Manager Access",
      ],
      cta: "Acquire Luxe Gold",
      badge: "Most Popular",
      isPopular: true
    },
    {
      name: "Elite Diamond Concierge",
      price: "$1,299",
      desc: "An ultra-premium operational partner for high-society empires and global fashion conglomerates.",
      features: [
        "Everything in Luxe Gold, plus:",
        "White-Glove Private Cloud Deployment",
        "24/7 VIP Concierge Direct Hot-Line",
        "Uncapped AI Content & Real-Time Analytics",
        "Custom Roles, Permissions, & Audit Logging",
        "Monthly Brand Strategy Audits",
      ],
      cta: "Request Membership VIP",
      badge: "Exclusive"
    }
  ];

  const features = [
    { title: "Luxe CRM Portfolio", desc: "Nurture high-profile relationships with elegance. Manage wealthy clientele profiles, contract values, and communication histories in glassmorphic cards.", icon: Star },
    { title: "Aura AI Strategist", desc: "Powered by Gemini, our customized luxury strategy engine coordinates marketing campaign themes, design aesthetics, and copywriting copy effortlessly.", icon: Sparkles },
    { title: "Bespoke Invoicing", desc: "Transaction elegance at its peak. Send gorgeous PDF invoices, configure automated payment reminders, and trace funds with real Stripe connections.", icon: DollarSign },
    { title: "Aesthetic Sprints", desc: "Manage projects, organize tasks, and schedule premium team rosters inside a customized dark berry drag-and-drop workflow dashboard.", icon: Compass },
  ];

  return (
    <div className="min-h-screen bg-[#130814] text-[#F5DCEB] selection:bg-[#FF2D8D] selection:text-white overflow-x-hidden relative" id="landing-page-root">
      
      {/* Absolute Ambient Background Blobs */}
      <div className="absolute top-[-10%] left-[-20%] w-[60%] h-[50%] bg-[#FF2D8D]/10 blur-[150px] rounded-full pointer-events-none z-0" />
      <div className="absolute top-[30%] right-[-10%] w-[50%] h-[60%] bg-[#FF78C5]/10 blur-[180px] rounded-full pointer-events-none z-0" />
      <div className="absolute bottom-[10%] left-[-10%] w-[40%] h-[50%] bg-[#E84D95]/10 blur-[140px] rounded-full pointer-events-none z-0" />

      {/* Floating Landing Header */}
      <nav className="max-w-7xl mx-auto px-8 h-24 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center shadow-[0_0_15px_rgba(255,45,141,0.5)]">
            <Sparkles className="text-white animate-pulse" size={18} />
          </div>
          <div className="flex flex-col">
            <span className="font-bold tracking-wider text-white text-lg font-sans">AURA ELYSIAN</span>
            <span className="text-[9px] uppercase tracking-widest text-[#FF78C5] font-mono leading-none">Luxury Suite</span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-sm text-[#D8B7CC] hover:text-white transition-colors">Features</a>
          <a href="#benefits" className="text-sm text-[#D8B7CC] hover:text-white transition-colors">Benefits</a>
          <a href="#pricing" className="text-sm text-[#D8B7CC] hover:text-white transition-colors">Pricing</a>
          <a href="#contact" className="text-sm text-[#D8B7CC] hover:text-white transition-colors">Contact</a>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setView("login")} 
            className="text-sm font-semibold text-[#D8B7CC] hover:text-white transition-colors cursor-pointer"
            id="landing-signin-nav"
          >
            Sign In
          </button>
          <button 
            onClick={() => setView("signup")} 
            className="px-5 py-2.5 rounded-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-sm font-bold shadow-[0_0_20px_rgba(255,45,141,0.4)] hover:shadow-[0_0_25px_rgba(255,45,141,0.6)] hover:scale-105 transition-all cursor-pointer"
            id="landing-signup-nav"
          >
            Apply for Access
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-8 pt-16 pb-24 relative z-10" id="hero-section">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Text */}
          <div className="lg:col-span-7 space-y-8 text-left">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#2A1830]/80 border border-[#4B2342] text-xs font-mono shadow-inner">
              <Sparkles className="text-[#FF2D8D] animate-spin" size={12} style={{ animationDuration: '6s' }} />
              <span className="text-[#F7A8D7] tracking-wider uppercase font-semibold">Luxury SaaS Command Center</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight tracking-tight">
              Aesthetic Operations for <br />
              <span className="bg-gradient-to-r from-[#FF2D8D] via-[#FF78C5] to-[#F7A8D7] bg-clip-text text-transparent drop-shadow-[0_2px_10px_rgba(255,45,141,0.2)]">
                Elite Feminine Empires
              </span>
            </h1>

            <p className="text-base md:text-lg text-[#D8B7CC] leading-relaxed max-w-xl">
              Darlings, step into absolute elegance. Aura Elysian merges high-end design with full-stack automation. Manage wealthy clientele, automate glassmorphic billing, analyze growth, and craft strategies with our custom Gemini-powered AI strategist.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-4 pt-4">
              <button 
                onClick={() => setView("signup")}
                className="w-full sm:w-auto px-8 py-4 rounded-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-base font-bold shadow-[0_0_30px_rgba(255,45,141,0.5)] hover:shadow-[0_0_40px_rgba(255,45,141,0.8)] hover:scale-105 transition-all cursor-pointer flex items-center justify-center gap-2"
                id="hero-primary-cta"
              >
                <span>Initialize Your Empire</span>
                <ChevronRight size={16} />
              </button>
              <a 
                href="#features"
                className="w-full sm:w-auto px-8 py-4 rounded-full bg-[#2A1830]/80 border border-[#4B2342] text-center text-sm font-bold hover:bg-[#311B37] hover:border-[#FF5FA8] transition-all cursor-pointer"
              >
                Explore Atelier Features
              </a>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-[#4B2342]/40 max-w-lg">
              <div>
                <p className="text-2xl md:text-3xl font-extrabold text-white">99.4%</p>
                <p className="text-[10px] uppercase font-mono tracking-wider text-[#D8B7CC]">Client Delight</p>
              </div>
              <div>
                <p className="text-2xl md:text-3xl font-extrabold text-white">$450M+</p>
                <p className="text-[10px] uppercase font-mono tracking-wider text-[#D8B7CC]">Wealth Tracked</p>
              </div>
              <div>
                <p className="text-2xl md:text-3xl font-extrabold text-white">2.5x</p>
                <p className="text-[10px] uppercase font-mono tracking-wider text-[#D8B7CC]">Revenue Velocity</p>
              </div>
            </div>
          </div>

          {/* Right Floating Glassmorphic Canvas Mockup */}
          <div className="lg:col-span-5 relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] rounded-3xl blur-[40px] opacity-25" />
            <div className="relative bg-[#2A1830]/90 backdrop-blur-xl border-2 border-[#5C2A50] rounded-3xl p-6 shadow-[0_20px_50px_rgba(0,0,0,0.5)] space-y-6">
              
              <div className="flex items-center justify-between border-b border-[#4B2342] pb-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-[#FF2D8D]" />
                  <div className="w-3 h-3 rounded-full bg-[#FF78C5]" />
                  <div className="w-3 h-3 rounded-full bg-[#5C2A50]" />
                </div>
                <span className="text-[10px] font-mono tracking-widest text-[#FF78C5] uppercase">Live Concierge Console</span>
              </div>

              {/* Sample AI Assistant UI on landing */}
              <div className="space-y-4">
                <div className="bg-[#190C1D] p-3 rounded-2xl border border-[#4B2342]/50 text-left">
                  <p className="text-[11px] font-mono text-[#D8B7CC]">PATRON QUESTION:</p>
                  <p className="text-xs text-white mt-1 font-medium">How do I align my cosmetic brand colors for a high-society launch?</p>
                </div>

                <div className="bg-[#311B37] p-3 rounded-2xl border border-[#5C2A50] text-left relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-[#FF2D8D]/10 blur-[15px] rounded-full" />
                  <p className="text-[11px] font-mono text-[#FF5FA8] flex items-center gap-1">
                    <Sparkles size={10} /> AURA STRATEGY AI:
                  </p>
                  <p className="text-xs text-[#F5DCEB] mt-1 leading-relaxed">
                    Darlings, for haute cosmetic branding, combine deep amethyst slate with glowing soft pink margins. Let's configure your invoices in gold-leaf typography to increase average order values by 32% instantly.
                  </p>
                </div>
              </div>

              {/* Sample Analytics Widget */}
              <div className="bg-gradient-to-r from-[#2A1830] to-[#190C1D] p-4 rounded-2xl border border-[#4B2342] flex items-center justify-between text-left">
                <div>
                  <span className="text-[10px] font-mono text-[#D8B7CC] uppercase tracking-wider">Aesthetic Revenue</span>
                  <p className="text-xl font-bold text-white mt-0.5">$84,500.00</p>
                </div>
                <div className="px-2.5 py-1 rounded-full bg-[#FF2D8D]/20 border border-[#FF2D8D]/40 text-[#FF5FA8] text-[10px] font-mono font-bold">
                  +18.4%
                </div>
              </div>

            </div>
          </div>

        </div>
      </section>

      {/* Features Grid */}
      <section className="max-w-7xl mx-auto px-8 py-24 border-t border-[#4B2342]/40 relative z-10 scroll-mt-10" id="features">
        <div className="text-center space-y-4 mb-16">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#FF2D8D]">Atelier Capabilities</span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">The Art of Sovereign Operations</h2>
          <p className="text-sm text-[#D8B7CC] max-w-lg mx-auto">Every operational detail is sculpted with pristine typography, beautiful spacing, and powerful, enterprise-grade capabilities.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div 
                key={idx}
                className="bg-[#2A1830]/60 backdrop-blur-md border border-[#4B2342] rounded-2xl p-6 text-left hover:border-[#FF2D8D] hover:shadow-[0_0_20px_rgba(255,45,141,0.15)] transition-all group"
              >
                <div className="w-12 h-12 rounded-xl bg-[#311B37] border border-[#5C2A50] flex items-center justify-center text-[#FF2D8D] group-hover:text-white group-hover:bg-gradient-to-tr group-hover:from-[#FF2D8D] group-hover:to-[#FF78C5] transition-all mb-6">
                  <Icon size={20} />
                </div>
                <h3 className="text-white font-bold text-lg mb-3">{feat.title}</h3>
                <p className="text-xs text-[#D8B7CC] leading-relaxed">{feat.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Benefits Bento Section */}
      <section className="max-w-7xl mx-auto px-8 py-16 border-t border-[#4B2342]/40 relative z-10" id="benefits">
        <div className="grid lg:grid-cols-12 gap-8">
          
          {/* Bento Panel 1 (Large Left) */}
          <div className="lg:col-span-7 bg-[#2A1830]/45 backdrop-blur-md border border-[#4B2342] rounded-3xl p-8 text-left relative overflow-hidden flex flex-col justify-between">
            <div className="absolute -top-12 -right-12 w-48 h-48 bg-[#FF2D8D]/5 blur-[50px] rounded-full pointer-events-none" />
            <div className="space-y-4">
              <span className="text-[10px] font-mono tracking-widest text-[#FF5FA8] uppercase font-bold">Unprecedented Velocity</span>
              <h3 className="text-2xl md:text-3xl font-extrabold text-white leading-tight">Elevate Client Lifecycle Value</h3>
              <p className="text-xs text-[#D8B7CC] leading-relaxed max-w-md">
                Elysian’s high-society dashboard streamlines CRM contracts and invoice issuance. Our client collectives report saving an average of 18 hours per week while escalating client trust by utilizing custom brand concierge reminders.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-6 pt-12 border-t border-[#4B2342]/40 mt-12">
              <div>
                <span className="text-3xl font-black text-white">40%</span>
                <p className="text-[10px] uppercase font-mono tracking-wider text-[#D8B7CC] mt-1">Faster Checkout</p>
              </div>
              <div>
                <span className="text-3xl font-black text-[#FF78C5] shadow-glow">3.2x</span>
                <p className="text-[10px] uppercase font-mono tracking-wider text-[#D8B7CC] mt-1">More Client Retention</p>
              </div>
            </div>
          </div>

          {/* Bento Panel 2 (Right Top/Bottom Stack) */}
          <div className="lg:col-span-5 flex flex-col gap-8">
            <div className="bg-[#2A1830]/80 backdrop-blur-md border border-[#5C2A50] rounded-3xl p-8 text-left relative overflow-hidden flex-1">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-[#FF2D8D]/10 flex items-center justify-center text-[#FF2D8D]">
                  <Star size={16} />
                </div>
                <span className="text-xs font-bold text-white uppercase tracking-wider">Premium Experience</span>
              </div>
              <h4 className="text-lg font-bold text-white mb-2">Absolute Privacy & Auditing</h4>
              <p className="text-xs text-[#D8B7CC] leading-relaxed">
                Configure customized team roles, view thorough security audit logs in real-time, and handle access keys with sovereign state protection.
              </p>
            </div>

            <div className="bg-gradient-to-tr from-[#311B37] to-[#190C1D] border border-[#4B2342] rounded-3xl p-8 text-left relative overflow-hidden flex-1">
              <h4 className="text-lg font-bold text-white mb-2">100% Google Sign-On</h4>
              <p className="text-xs text-[#D8B7CC] leading-relaxed mb-4">
                Instantly connect, secure your accounts, sync schedules with Google Calendar, and manage contracts safely with single-click OAuth integrations.
              </p>
              <button 
                onClick={() => setView("signup")}
                className="text-xs font-bold tracking-widest text-[#FF5FA8] hover:text-white transition-colors uppercase font-mono flex items-center gap-1.5"
              >
                <span>Activate sovereign login</span>
                <ChevronRight size={12} />
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* Pricing Cards */}
      <section className="max-w-7xl mx-auto px-8 py-24 border-t border-[#4B2342]/40 relative z-10 scroll-mt-10" id="pricing">
        <div className="text-center space-y-4 mb-16">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#FF2D8D]">Membership Investitures</span>
          <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">Curate Your Sovereign Tier</h2>
          <p className="text-sm text-[#D8B7CC] max-w-lg mx-auto">Select the perfect operational suite darlings. Transparent pricing tailored for premium boutiques and international empires.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 items-stretch">
          {pricingTiers.map((tier, idx) => (
            <div 
              key={idx}
              className={`rounded-3xl p-8 text-left relative flex flex-col justify-between transition-all hover:scale-[1.02] ${
                tier.isPopular 
                  ? "bg-[#311B37] border-2 border-[#FF2D8D] shadow-[0_0_35px_rgba(255,45,141,0.25)]" 
                  : "bg-[#2A1830]/70 border border-[#4B2342]"
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#FF5FA8] font-mono px-2.5 py-1 rounded-full bg-[#130814]/60 border border-[#4B2342]">
                    {tier.badge}
                  </span>
                </div>
                <h3 className="text-white text-2xl font-bold mb-2">{tier.name}</h3>
                <p className="text-xs text-[#D8B7CC] leading-relaxed mb-6 h-12">{tier.desc}</p>
                
                <div className="flex items-baseline gap-1.5 mb-8">
                  <span className="text-4xl font-black text-white">{tier.price}</span>
                  <span className="text-xs text-[#D8B7CC] font-mono uppercase tracking-wider">/ Month</span>
                </div>

                <div className="space-y-3 mb-8">
                  {tier.features.map((feat, fIdx) => (
                    <div key={fIdx} className="flex items-start gap-2.5">
                      <Check size={14} className="text-[#FF2D8D] shrink-0 mt-0.5" />
                      <span className="text-xs text-[#F5DCEB]">{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button 
                onClick={() => {
                  setView("signup");
                  addToast(`Membership application initiated for ${tier.name}!`);
                }}
                className={`w-full py-3.5 rounded-full text-xs font-bold tracking-widest uppercase transition-all cursor-pointer ${
                  tier.isPopular 
                    ? "bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white shadow-[0_0_20px_rgba(255,45,141,0.4)] hover:shadow-[0_0_30px_rgba(255,45,141,0.6)]" 
                    : "bg-[#130814] text-white border border-[#4B2342] hover:border-[#FF2D8D] hover:shadow-[0_0_15px_rgba(255,45,141,0.15)]"
                }`}
                id={`pricing-tier-${idx}`}
              >
                {tier.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* About Collective Section */}
      <section className="max-w-7xl mx-auto px-8 py-16 border-t border-[#4B2342]/40 relative z-10" id="about">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-6 text-left">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#FF2D8D]">Elysian Philosophy</span>
            <h2 className="text-3xl font-bold text-white tracking-tight">Crafted for Sophisticated Growth</h2>
            <p className="text-xs text-[#D8B7CC] leading-relaxed">
              We believe business software should be as inspiring as high fashion. Aura Elysian is co-designed by prominent female product architects and brand consultants who reject flat, dry dashboards in favor of rich velvet berry backgrounds, elegant glowing outlines, and state-of-the-art automation.
            </p>
            <p className="text-xs text-[#D8B7CC] leading-relaxed">
              Our ultimate vision is to give luxury feminine boutiques, wellness brands, and creative collectives the exact visual luxury they deserve while guaranteeing bulletproof PostgreSQL data persistence, robust real-time API integrations, and premium AI strategists.
            </p>
          </div>
          <div className="lg:col-span-6">
            <div className="p-8 rounded-3xl bg-[#2A1830]/80 border border-[#4B2342] relative text-left">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF2D8D]/5 blur-[35px] rounded-full pointer-events-none" />
              <div className="flex items-center gap-3.5 mb-6">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center font-bold text-[#F5DCEB]">
                  CH
                </div>
                <div>
                  <h4 className="text-white text-sm font-bold">Camila Hadid</h4>
                  <p className="text-[10px] font-mono uppercase tracking-wider text-[#FF5FA8]">CEO, Hadid Fine Jewelry</p>
                </div>
              </div>
              <p className="text-xs italic text-[#F5DCEB] leading-relaxed">
                "Darlings, switching my operations to Aura Elysian was the single most luxury upgrade Hadid Jewelry ever made. Our invoicing looks sublime, our CRM leads are nurtured by the customized Gemini Strategist, and our administrative tracking is fully automated. Simply elite."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Contact Form */}
      <section className="max-w-7xl mx-auto px-8 py-24 border-t border-[#4B2342]/40 relative z-10 scroll-mt-10" id="contact">
        <div className="grid lg:grid-cols-12 gap-12">
          
          {/* Info Card */}
          <div className="lg:col-span-5 text-left space-y-6">
            <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#FF2D8D]">Inquire Access</span>
            <h2 className="text-3xl font-extrabold text-white">Join the Sovereign Collective</h2>
            <p className="text-xs text-[#D8B7CC] leading-relaxed">
              Would you like to initiate a private consultation or request custom deployment configurations for your international enterprise, darlings?
            </p>
            <div className="space-y-4 pt-4 text-xs font-medium">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#2A1830] border border-[#4B2342] flex items-center justify-center text-[#FF2D8D]">
                  <Star size={14} />
                </div>
                <span>concierge@auraelysian.com</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#2A1830] border border-[#4B2342] flex items-center justify-center text-[#FF2D8D]">
                  <Globe size={14} />
                </div>
                <span>London · Paris · Milan · Tokyo</span>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-7">
            <div className="bg-[#2A1830]/85 backdrop-blur-xl border border-[#5C2A50] rounded-3xl p-8 shadow-2xl">
              <form onSubmit={handleContactSubmit} className="space-y-5 text-left">
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Your Noble Name</label>
                    <input 
                      type="text"
                      required
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      placeholder="e.g. Charlotte Dupond"
                      className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-4 py-3 text-xs text-white placeholder-[#D8B7CC]/40 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.2)]"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Secure Email Address</label>
                    <input 
                      type="email"
                      required
                      value={contactForm.email}
                      onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                      placeholder="e.g. charlotte@maisondupond.fr"
                      className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-4 py-3 text-xs text-white placeholder-[#D8B7CC]/40 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.2)]"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Agency or Maison Name</label>
                  <input 
                    type="text"
                    value={contactForm.agency}
                    onChange={(e) => setContactForm({ ...contactForm, agency: e.target.value })}
                    placeholder="e.g. Maison Dupond Perfumerie"
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-4 py-3 text-xs text-white placeholder-[#D8B7CC]/40 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.2)]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Custom Request or Vision</label>
                  <textarea 
                    rows={4}
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    placeholder="Darlings, outline your operational requirements or design aesthetic..."
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-4 py-3 text-xs text-white placeholder-[#D8B7CC]/40 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.2)] resize-none"
                  />
                </div>

                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(255,45,141,0.4)] hover:shadow-[0_0_30px_rgba(255,45,141,0.6)] cursor-pointer transition-all flex items-center justify-center gap-2"
                  id="contact-form-submit-btn"
                >
                  {isSubmitting ? <span>Transmitting...</span> : (
                    <>
                      <span>Transmit Request</span>
                      <Send size={12} />
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#4B2342]/40 bg-[#140816] py-12 relative z-10 text-xs text-[#D8B7CC]/60 text-center">
        <div className="max-w-7xl mx-auto px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center text-white">
              <Sparkles size={14} />
            </div>
            <span className="font-bold text-white tracking-widest font-mono text-sm">AURA ELYSIAN</span>
          </div>
          <p>© 2026 Aura Elysian Collective. All rights reserved. Empowering high-society enterprises.</p>
          <div className="flex gap-6">
            <span className="hover:text-white cursor-pointer">Terms of Elegance</span>
            <span className="hover:text-white cursor-pointer">Privacy Charter</span>
          </div>
        </div>
      </footer>

    </div>
  );
};
