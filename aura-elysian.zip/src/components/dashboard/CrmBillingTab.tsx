import React, { useState } from "react";
import { useApp } from "../../context/AppContext";
import { Sparkles, Plus, Users, Receipt, CreditCard, DollarSign, Send, Crown, Check, Search, Filter } from "lucide-react";

export const CrmBillingTab: React.FC = () => {
  const { 
    leads, invoices, payments, addLead, addInvoice, addToast 
  } = useApp();

  // Active sub-section state
  const [activeSection, setActiveSection] = useState<"crm" | "invoices" | "payments">("crm");

  // Lead inputs
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [leadName, setLeadName] = useState("");
  const [leadEmail, setLeadEmail] = useState("");
  const [leadCompany, setLeadCompany] = useState("");
  const [leadValue, setLeadValue] = useState("");
  const [leadService, setLeadService] = useState("Elite Branding");

  // Invoice inputs
  const [showInvoiceForm, setShowInvoiceForm] = useState(false);
  const [invClient, setInvClient] = useState("");
  const [invAmount, setInvAmount] = useState("");

  const handleCreateLead = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leadName || !leadEmail) {
      addToast("Darlings, please fill in your client's name and email.", "error");
      return;
    }
    await addLead({
      name: leadName,
      email: leadEmail,
      company: leadCompany || "Private Individual",
      status: "Active Lead",
      value: leadValue || "$25,000",
      service: leadService
    });
    setLeadName("");
    setLeadEmail("");
    setLeadCompany("");
    setLeadValue("");
    setShowLeadForm(false);
  };

  const handleCreateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!invClient || !invAmount) {
      addToast("Darlings, client name and invoice amount are required.", "error");
      return;
    }
    await addInvoice({
      client: invClient,
      amount: invAmount,
      status: "Sent"
    });
    setInvClient("");
    setInvAmount("");
    setShowInvoiceForm(false);
  };

  return (
    <div className="space-y-8 text-left" id="crm-billing-tab-root">
      
      {/* Dynamic Sub-Navigation Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#4B2342] pb-6">
        <div className="flex items-center gap-2.5 bg-[#190C1D] border border-[#4B2342] p-1 rounded-2xl shrink-0">
          <button
            onClick={() => setActiveSection("crm")}
            className={`px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
              activeSection === "crm" 
                ? "bg-[#2A1830] text-[#FF5FA8] border border-[#5C2A50] shadow-md" 
                : "text-[#D8B7CC]/60 hover:text-white"
            }`}
            id="crm-section-tab"
          >
            <Users size={13} />
            <span>CRM Leads</span>
          </button>
          <button
            onClick={() => setActiveSection("invoices")}
            className={`px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
              activeSection === "invoices" 
                ? "bg-[#2A1830] text-[#FF5FA8] border border-[#5C2A50] shadow-md" 
                : "text-[#D8B7CC]/60 hover:text-white"
            }`}
            id="invoices-section-tab"
          >
            <Receipt size={13} />
            <span>Invoices Ledger</span>
          </button>
          <button
            onClick={() => setActiveSection("payments")}
            className={`px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
              activeSection === "payments" 
                ? "bg-[#2A1830] text-[#FF5FA8] border border-[#5C2A50] shadow-md" 
                : "text-[#D8B7CC]/60 hover:text-white"
            }`}
            id="payments-section-tab"
          >
            <CreditCard size={13} />
            <span>Stripe Payments</span>
          </button>
        </div>

        {activeSection === "crm" && (
          <button 
            onClick={() => setShowLeadForm(!showLeadForm)}
            className="px-4 py-2.5 rounded-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest shadow-md hover:scale-105 transition-all cursor-pointer flex items-center gap-2"
            id="lead-create-btn"
          >
            <Plus size={14} />
            <span>Record Luxury Lead</span>
          </button>
        )}

        {activeSection === "invoices" && (
          <button 
            onClick={() => setShowInvoiceForm(!showInvoiceForm)}
            className="px-4 py-2.5 rounded-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest shadow-md hover:scale-105 transition-all cursor-pointer flex items-center gap-2"
            id="invoice-create-btn"
          >
            <Plus size={14} />
            <span>Issue Invoice</span>
          </button>
        )}
      </div>

      {/* --- SECTION 1: CRM LEADS LIST --- */}
      {activeSection === "crm" && (
        <div className="space-y-6">
          <div className="text-left">
            <h3 className="text-lg font-bold text-white tracking-tight">Luxury Brand Pipeline</h3>
            <p className="text-xs text-[#D8B7CC]">Manage wealthy leads, aesthetic clinics inquiries, and contract estimations.</p>
          </div>

          {/* Lead Creation Form */}
          {showLeadForm && (
            <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-xl max-w-2xl">
              <h4 className="text-white font-bold text-xs mb-4 uppercase tracking-widest font-mono flex items-center gap-1.5">
                <Crown size={12} className="text-[#FF2D8D]" /> Record Patron Interest
              </h4>
              <form onSubmit={handleCreateLead} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Patron Name</label>
                  <input 
                    type="text"
                    required
                    value={leadName}
                    onChange={(e) => setLeadName(e.target.value)}
                    placeholder="e.g. Charlotte Dupond"
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Patron Email</label>
                  <input 
                    type="email"
                    required
                    value={leadEmail}
                    onChange={(e) => setLeadEmail(e.target.value)}
                    placeholder="e.g. charlotte@maisondupond.fr"
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Noble Company / Maison</label>
                  <input 
                    type="text"
                    value={leadCompany}
                    onChange={(e) => setLeadCompany(e.target.value)}
                    placeholder="e.g. Maison Dupond Perfumerie"
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Estimated Contract Value</label>
                  <input 
                    type="text"
                    value={leadValue}
                    onChange={(e) => setLeadValue(e.target.value)}
                    placeholder="e.g. $62,000"
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                  />
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Requested Creative service</label>
                  <select 
                    value={leadService}
                    onChange={(e) => setLeadService(e.target.value)}
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3 py-2.5 text-xs text-[#D8B7CC] outline-none"
                  >
                    <option value="Elite Branding">Elite Sovereign Branding</option>
                    <option value="Full-Scale Launch">Full-Scale Atelier Launch</option>
                    <option value="CRM Automation">CRM Automation & Calendar Integration</option>
                    <option value="E-Commerce Luxury">E-Commerce Luxury Rebuild</option>
                  </select>
                </div>

                <div className="sm:col-span-2 pt-2 flex items-center justify-end gap-2">
                  <button type="button" onClick={() => setShowLeadForm(false)} className="px-3 py-1.5 text-xs text-[#D8B7CC]">Cancel</button>
                  <button type="submit" className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest">Register Lead</button>
                </div>
              </form>
            </div>
          )}

          {/* CRM Data Table */}
          <div className="bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#190C1D] border-b border-[#4B2342] text-[10px] uppercase font-mono tracking-widest text-[#D8B7CC]">
                    <th className="p-4 pl-6">Noble Contact</th>
                    <th className="p-4">Maison / Company</th>
                    <th className="p-4">Creative Request</th>
                    <th className="p-4">Trace Date</th>
                    <th className="p-4">Est Value</th>
                    <th className="p-4 pr-6">Sovereign Status</th>
                  </tr>
                </thead>
                <tbody className="text-xs divide-y divide-[#4B2342]/50">
                  {leads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-[#311B37]/35 transition-colors">
                      <td className="p-4 pl-6 font-semibold text-white">
                        <div>{lead.name}</div>
                        <div className="text-[10px] text-[#D8B7CC] font-normal font-mono mt-0.5">{lead.email}</div>
                      </td>
                      <td className="p-4 text-[#D8B7CC] font-medium">{lead.company}</td>
                      <td className="p-4 text-[#D8B7CC]">{lead.service}</td>
                      <td className="p-4 text-[#D8B7CC]/75 font-mono">{lead.date}</td>
                      <td className="p-4 font-bold text-white font-mono">{lead.value}</td>
                      <td className="p-4 pr-6">
                        <span className="px-2 py-0.5 rounded-full bg-[#FF2D8D]/15 text-[#FF2D8D] font-mono text-[9px] uppercase font-bold tracking-widest border border-[#FF2D8D]/20">
                          {lead.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --- SECTION 2: INVOICES --- */}
      {activeSection === "invoices" && (
        <div className="space-y-6">
          <div className="text-left">
            <h3 className="text-lg font-bold text-white tracking-tight">Luxury Invoicing Ledger</h3>
            <p className="text-xs text-[#D8B7CC]">Dispatch beautifully branded payment drafts with automated tracking.</p>
          </div>

          {/* Invoice Creation Form */}
          {showInvoiceForm && (
            <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-xl max-w-xl">
              <h4 className="text-white font-bold text-xs mb-3 uppercase tracking-widest font-mono">Draft Branded Invoice</h4>
              <form onSubmit={handleCreateInvoice} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Maison Client</label>
                  <input 
                    type="text"
                    required
                    value={invClient}
                    onChange={(e) => setInvClient(e.target.value)}
                    placeholder="e.g. Moretti Haute Couture"
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Invoice Amount</label>
                  <input 
                    type="text"
                    required
                    value={invAmount}
                    onChange={(e) => setInvAmount(e.target.value)}
                    placeholder="e.g. $22,500"
                    className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                  />
                </div>

                <div className="sm:col-span-2 pt-2 flex items-center justify-end gap-2">
                  <button type="button" onClick={() => setShowInvoiceForm(false)} className="px-3 py-1.5 text-xs text-[#D8B7CC]">Cancel</button>
                  <button type="submit" className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest">Issue Invoice</button>
                </div>
              </form>
            </div>
          )}

          {/* Invoices Ledger Table */}
          <div className="bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#190C1D] border-b border-[#4B2342] text-[10px] uppercase font-mono tracking-widest text-[#D8B7CC]">
                    <th className="p-4 pl-6">Invoice ID</th>
                    <th className="p-4">Maison Client</th>
                    <th className="p-4">Dispatched Date</th>
                    <th className="p-4">Due Date</th>
                    <th className="p-4">Total Amount</th>
                    <th className="p-4 pr-6">Payment Status</th>
                  </tr>
                </thead>
                <tbody className="text-xs divide-y divide-[#4B2342]/50">
                  {invoices.map((inv) => (
                    <tr key={inv.id} className="hover:bg-[#311B37]/35 transition-colors">
                      <td className="p-4 pl-6 font-mono font-bold text-white">{inv.id}</td>
                      <td className="p-4 text-[#D8B7CC] font-semibold">{inv.client}</td>
                      <td className="p-4 text-[#D8B7CC]/80 font-mono">{inv.issued}</td>
                      <td className="p-4 text-[#D8B7CC]/80 font-mono">{inv.due}</td>
                      <td className="p-4 text-white font-mono font-bold">{inv.amount}</td>
                      <td className="p-4 pr-6">
                        <span className={`px-2.5 py-0.5 rounded-full text-[9px] uppercase font-mono font-bold tracking-wider border ${
                          inv.status === "Paid" 
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                            : inv.status === "Sent"
                              ? "bg-[#FF78C5]/10 text-[#FF78C5] border-[#FF78C5]/20"
                              : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                        }`}>
                          {inv.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --- SECTION 3: STRIPE PAYMENTS --- */}
      {activeSection === "payments" && (
        <div className="space-y-6">
          <div className="text-left">
            <h3 className="text-lg font-bold text-white tracking-tight">Express Stripe Payments Gateway</h3>
            <p className="text-xs text-[#D8B7CC]">Audit successful merchant transactions, currency transfers, and deposits.</p>
          </div>

          <div className="bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-[#190C1D] border-b border-[#4B2342] text-[10px] uppercase font-mono tracking-widest text-[#D8B7CC]">
                    <th className="p-4 pl-6">Transaction ID</th>
                    <th className="p-4">Associated Invoice</th>
                    <th className="p-4">Maison Client</th>
                    <th className="p-4">Cleared Timestamp</th>
                    <th className="p-4">Deposit Method</th>
                    <th className="p-4">Amount</th>
                    <th className="p-4 pr-6">Stripe Status</th>
                  </tr>
                </thead>
                <tbody className="text-xs divide-y divide-[#4B2342]/50">
                  {payments.map((pay) => (
                    <tr key={pay.id} className="hover:bg-[#311B37]/35 transition-colors">
                      <td className="p-4 pl-6 font-mono font-bold text-white">{pay.id}</td>
                      <td className="p-4 text-[#D8B7CC] font-mono">{pay.invoiceId}</td>
                      <td className="p-4 text-white font-semibold">{pay.client}</td>
                      <td className="p-4 text-[#D8B7CC]/75 font-mono">{pay.date}</td>
                      <td className="p-4 text-[#D8B7CC] font-medium">{pay.method}</td>
                      <td className="p-4 font-black text-white font-mono">{pay.amount}</td>
                      <td className="p-4 pr-6">
                        <div className="flex items-center gap-1.5 text-emerald-400 font-bold font-mono text-[10px] uppercase">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          <span>Cleared Success</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
