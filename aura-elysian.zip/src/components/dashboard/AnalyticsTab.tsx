import React from "react";
import { useApp } from "../../context/AppContext";
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar 
} from "recharts";
import { Sparkles, DollarSign, Users, Activity, TrendingUp, Compass, Heart } from "lucide-react";

export const AnalyticsTab: React.FC = () => {
  const { leads, projects, invoices, payments } = useApp();

  // Custom luxury mock data for charts
  const revenueData = [
    { name: "Jan", luxuryRevenue: 34000, organicLeads: 12 },
    { name: "Feb", luxuryRevenue: 45000, organicLeads: 18 },
    { name: "Mar", luxuryRevenue: 52000, organicLeads: 22 },
    { name: "Apr", luxuryRevenue: 61000, organicLeads: 29 },
    { name: "May", luxuryRevenue: 85000, organicLeads: 35 },
    { name: "Jun", luxuryRevenue: 98000, organicLeads: 42 }
  ];

  const categoryPerformance = [
    { category: "Branding", revenue: 45000, color: "#FF2D8D" },
    { category: "Atelier Apps", revenue: 62000, color: "#FF78C5" },
    { category: "CRM Integration", revenue: 28000, color: "#E84D95" },
    { category: "White-Glove VIP", revenue: 35000, color: "#F7A8D7" }
  ];

  // Calculate high-end metrics
  const totalWealthTracked = payments
    .filter(p => p.status === "Success")
    .reduce((acc, curr) => acc + Number(curr.amount.replace(/[^0-9]/g, "")), 0);

  return (
    <div className="space-y-8 text-left" id="analytics-tab-root">
      
      {/* Top Welcome Title */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Luxury Command Center</h2>
          <p className="text-xs text-[#D8B7CC]">Aesthetic oversight, financial progression, and pipeline analytics.</p>
        </div>
        <div className="flex items-center gap-2 bg-[#2A1830] border border-[#4B2342] px-3.5 py-1.5 rounded-full text-xs text-[#FF5FA8] font-mono shadow-inner">
          <Sparkles size={12} className="text-[#FF2D8D] animate-spin" style={{ animationDuration: '8s' }} />
          <span>Aura Predictor: Peak Velocity Mode</span>
        </div>
      </div>

      {/* Luxury KPI Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* KPI 1: Revenue */}
        <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 relative overflow-hidden group hover:border-[#FF2D8D] hover:shadow-[0_10px_30px_rgba(255,45,141,0.15)] transition-all shadow-xl">
          <div className="absolute top-0 right-0 w-20 h-20 bg-[#FF2D8D]/5 blur-[20px] rounded-full" />
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]">Sovereign Wealth</span>
            <div className="w-8 h-8 rounded-lg bg-[#311B37] border border-[#5C2A50] flex items-center justify-center text-[#FF2D8D]">
              <DollarSign size={15} />
            </div>
          </div>
          <p className="text-2xl font-black text-white mt-4">$50,500.00</p>
          <div className="flex items-center gap-1.5 mt-2.5 text-xs">
            <span className="text-[#FF5FA8] font-bold">+18.4%</span>
            <span className="text-[#D8B7CC]/60 font-mono">VS last epoch</span>
          </div>
        </div>

        {/* KPI 2: Active Clients */}
        <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 relative overflow-hidden group hover:border-[#FF2D8D] hover:shadow-[0_10px_30px_rgba(255,45,141,0.15)] transition-all shadow-xl">
          <div className="absolute top-0 right-0 w-20 h-20 bg-[#FF78C5]/5 blur-[20px] rounded-full" />
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]">Honored Patrons</span>
            <div className="w-8 h-8 rounded-lg bg-[#311B37] border border-[#5C2A50] flex items-center justify-center text-[#FF78C5]">
              <Users size={15} />
            </div>
          </div>
          <p className="text-2xl font-black text-white mt-4">{leads.length + 3}</p>
          <div className="flex items-center gap-1.5 mt-2.5 text-xs">
            <span className="text-[#FF5FA8] font-bold">+28.5%</span>
            <span className="text-[#D8B7CC]/60 font-mono">conversion rate</span>
          </div>
        </div>

        {/* KPI 3: Projects Velocity */}
        <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 relative overflow-hidden group hover:border-[#FF2D8D] hover:shadow-[0_10px_30px_rgba(255,45,141,0.15)] transition-all shadow-xl">
          <div className="absolute top-0 right-0 w-20 h-20 bg-[#E84D95]/5 blur-[20px] rounded-full" />
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]">Aesthetic Sprints</span>
            <div className="w-8 h-8 rounded-lg bg-[#311B37] border border-[#5C2A50] flex items-center justify-center text-[#E84D95]">
              <Compass size={15} />
            </div>
          </div>
          <p className="text-2xl font-black text-white mt-4">{projects.length}</p>
          <div className="flex items-center gap-1.5 mt-2.5 text-xs">
            <span className="text-[#FF5FA8] font-bold">75%</span>
            <span className="text-[#D8B7CC]/60 font-mono">avg progression</span>
          </div>
        </div>

        {/* KPI 4: Financial Efficiency */}
        <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 relative overflow-hidden group hover:border-[#FF2D8D] hover:shadow-[0_10px_30px_rgba(255,45,141,0.15)] transition-all shadow-xl">
          <div className="absolute top-0 right-0 w-20 h-20 bg-[#F7A8D7]/5 blur-[20px] rounded-full" />
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]">Aura Pulse</span>
            <div className="w-8 h-8 rounded-lg bg-[#311B37] border border-[#5C2A50] flex items-center justify-center text-[#F7A8D7]">
              <Activity size={15} />
            </div>
          </div>
          <p className="text-2xl font-black text-white mt-4">99.4%</p>
          <div className="flex items-center gap-1.5 mt-2.5 text-xs">
            <span className="text-[#FF5FA8] font-bold">Absolute</span>
            <span className="text-[#D8B7CC]/60 font-mono">Uptime Authorized</span>
          </div>
        </div>

      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Chart 1: Revenue Area Chart (Glassmorphic) */}
        <div className="lg:col-span-8 bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] p-6 lg:p-8 shadow-2xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-white font-bold text-base">Financial Expansion Track</h3>
              <p className="text-[11px] text-[#D8B7CC]">Continuous trace of organic expansion, luxury invoicing & leads volume.</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-xs text-[#D8B7CC] font-mono">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FF2D8D]" />
                Revenue ($)
              </span>
              <span className="flex items-center gap-1.5 text-xs text-[#D8B7CC] font-mono">
                <span className="w-2.5 h-2.5 rounded-full bg-[#FF78C5]" />
                Leads
              </span>
            </div>
          </div>

          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF2D8D" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#FF2D8D" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF78C5" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#FF78C5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#4B2342" opacity={0.3} />
                <XAxis dataKey="name" stroke="#D8B7CC" fontSize={11} tickLine={false} />
                <YAxis stroke="#D8B7CC" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: "#2A1830", 
                    borderColor: "#5C2A50", 
                    borderRadius: "16px",
                    color: "#FFFFFF",
                    fontSize: "12px",
                    boxShadow: "0 10px 30px rgba(0,0,0,0.5)"
                  }} 
                />
                <Area type="monotone" dataKey="luxuryRevenue" name="Revenue" stroke="#FF2D8D" strokeWidth={2} fillOpacity={1} fill="url(#colorRevenue)" />
                <Area type="monotone" dataKey="organicLeads" name="Leads" stroke="#FF78C5" strokeWidth={2} fillOpacity={1} fill="url(#colorLeads)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Category Bar Chart */}
        <div className="lg:col-span-4 bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl flex flex-col justify-between">
          <div>
            <h3 className="text-white font-bold text-base">Atelier Allocation</h3>
            <p className="text-[11px] text-[#D8B7CC] mb-6">Distribution of wealth across services.</p>
            
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryPerformance} margin={{ top: 0, right: 0, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#4B2342" opacity={0.2} />
                  <XAxis dataKey="category" stroke="#D8B7CC" fontSize={9} tickLine={false} />
                  <YAxis stroke="#D8B7CC" fontSize={9} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "#2A1830", 
                      borderColor: "#5C2A50", 
                      borderRadius: "12px",
                      color: "#FFFFFF",
                      fontSize: "11px"
                    }} 
                  />
                  <Bar dataKey="revenue" name="Bespoke Value" radius={[8, 8, 0, 0]}>
                    {categoryPerformance.map((entry, index) => (
                      <rect key={index} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-4 border-t border-[#4B2342]/40 text-left">
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#FF5FA8] font-bold">Total VIP Capitalizer</span>
            <p className="text-lg font-bold text-white mt-0.5">$170,000.00 Authorized</p>
          </div>
        </div>

      </div>

      {/* Under Section: Recent Payments & Pipeline status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Leads summary table */}
        <div className="lg:col-span-6 bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-bold text-sm">Pipeline Highlights</h3>
            <span className="text-xs font-mono text-[#FF5FA8]">VIP Contacts</span>
          </div>

          <div className="space-y-3">
            {leads.slice(0, 3).map((lead) => (
              <div key={lead.id} className="flex items-center justify-between p-3 rounded-xl bg-[#190C1D]/60 border border-[#4B2342] hover:border-[#FF2D8D] transition-colors text-left">
                <div>
                  <h4 className="text-white font-semibold text-xs leading-tight">{lead.name}</h4>
                  <p className="text-[10px] text-[#D8B7CC] mt-0.5">{lead.company}</p>
                </div>
                <div className="text-right">
                  <span className="text-white font-bold text-xs">{lead.value}</span>
                  <p className="text-[9px] uppercase font-mono tracking-widest text-[#FF78C5] mt-0.5">{lead.status}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Billing Overview */}
        <div className="lg:col-span-6 bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl flex flex-col justify-between">
          <div className="text-left space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold text-sm">Active Subscription</h3>
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#FF5FA8] bg-[#FF2D8D]/10 px-2.5 py-0.5 rounded-full border border-[#FF2D8D]/30 shadow-[0_0_10px_rgba(255,45,141,0.2)]">
                Elite VIP
              </span>
            </div>

            <p className="text-xs text-[#D8B7CC] leading-relaxed">
              Your suite is configured on the **Elite Diamond Concierge** membership subscription. Complete features, unmetered AI Strategy consultations, and white-glove cloud servers are active. Next invoice issues on **July 15, 2026**.
            </p>
          </div>

          <div className="pt-4 border-t border-[#4B2342]/40 flex items-center justify-between mt-6">
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]">Current Velocity</span>
              <p className="text-xs text-[#FF5FA8] font-bold mt-0.5">Stripe Active Verified</p>
            </div>
            <button className="px-4 py-2 rounded-full bg-[#130814] border border-[#4B2342] hover:border-[#FF2D8D] text-white text-[10px] font-bold uppercase tracking-widest transition-all">
              Manage Billing Portal
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
