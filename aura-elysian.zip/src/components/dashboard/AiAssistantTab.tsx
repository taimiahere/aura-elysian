import React, { useState, useRef, useEffect } from "react";
import { useApp } from "../../context/AppContext";
import { Sparkles, Send, Trash2, HelpCircle, Bot, Compass, Crown, Zap } from "lucide-react";
import { motion } from "motion/react";

export const AiAssistantTab: React.FC = () => {
  const { aiChatHistory, isAiTyping, sendChatMessage, clearChat, addToast } = useApp();
  const [prompt, setPrompt] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to chat end
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [aiChatHistory, isAiTyping]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    const msg = prompt;
    setPrompt("");
    await sendChatMessage(msg);
  };

  const handleQuickPrompt = async (text: string) => {
    addToast(`Transmitting luxurious request: "${text.substring(0, 30)}..."`, "info");
    await sendChatMessage(text);
  };

  const quickPrompts = [
    { title: "Luxe Color Strategy", query: "Give me an ultra-premium color palette and typeface pairing for an organic luxury aesthetic salon launch." },
    { title: "Elite Pricing Model", query: "Can you design a 3-tier high-ticket pricing scheme for high-fashion boutique digital consultants?" },
    { title: "VIP Invoice Campaign", query: "Draft a polite, highly sophisticated payment request template for high-profile clients." }
  ];

  return (
    <div className="h-[calc(100vh-12rem)] flex flex-col lg:grid lg:grid-cols-12 gap-6 text-left" id="ai-assistant-tab-root">
      
      {/* Left: Quick Prompts & AI Profile Desk */}
      <div className="lg:col-span-4 bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 flex flex-col justify-between shadow-2xl shrink-0">
        <div className="space-y-6">
          <div className="flex items-center gap-3.5 pb-4 border-b border-[#4B2342]">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center shadow-[0_0_15px_rgba(255,45,141,0.5)]">
              <Crown className="text-white animate-pulse" size={20} />
            </div>
            <div>
              <h3 className="text-white font-bold text-sm">AURA Concierge AI</h3>
              <p className="text-[10px] font-mono text-[#FF5FA8] uppercase tracking-wider font-semibold">Senior Brand Strategy Director</p>
            </div>
          </div>

          <div className="space-y-4 text-xs leading-relaxed text-[#D8B7CC]">
            <p>
              Step into high-society intelligence, darlings. Powered by server-side Gemini, our AI Strategist specializes in refining visual palettes, copywriting elite sales models, and structuring boutique invoicing.
            </p>
            <p>
              Click any luxury blueprint shortcut below to let Aura coordinate your operational pipelines instantly.
            </p>
          </div>

          {/* Quick Prompts shortcuts */}
          <div className="space-y-3 pt-2">
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC]/60 font-bold block">Conceive Blueprint</span>
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleQuickPrompt(qp.query)}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-[#130814]/50 border border-[#4B2342] hover:border-[#FF2D8D] hover:shadow-[0_0_10px_rgba(255,45,141,0.1)] text-left transition-all cursor-pointer group"
              >
                <div className="min-w-0">
                  <span className="text-white text-xs font-semibold block">{qp.title}</span>
                  <span className="text-[9px] text-[#D8B7CC] truncate block mt-0.5">{qp.query}</span>
                </div>
                <Compass size={13} className="text-[#FF2D8D] group-hover:rotate-45 transition-transform shrink-0 ml-3" />
              </button>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-[#4B2342]/40 flex items-center justify-between">
          <span className="text-[10px] text-[#D8B7CC]/60 font-mono">Server SSL Protected</span>
          <button 
            onClick={clearChat}
            className="text-[10px] font-bold text-[#FF5FA8] hover:text-[#FF2D8D] transition-colors uppercase font-mono flex items-center gap-1 cursor-pointer"
          >
            <Trash2 size={11} /> Clear Conversation
          </button>
        </div>
      </div>

      {/* Right: Active Chat Area */}
      <div className="lg:col-span-8 bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] flex flex-col justify-between shadow-2xl overflow-hidden min-h-0">
        
        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5 scrollbar-thin scrollbar-thumb-[#4B2342]">
          {aiChatHistory.map((chat, idx) => {
            const isUser = chat.role === "user";
            return (
              <div 
                key={idx}
                className={`flex gap-4 items-start ${isUser ? "flex-row-reverse text-right" : "text-left"}`}
              >
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 border ${
                  isUser 
                    ? "bg-[#130814] border-[#4B2342] text-white" 
                    : "bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] border-[#FF2D8D]/40 text-white shadow-[0_0_10px_rgba(255,45,141,0.3)] animate-pulse"
                }`}>
                  {isUser ? "ME" : <Crown size={12} />}
                </div>

                {/* Message Bubble with glassmorphism */}
                <div className={`max-w-[80%] rounded-2xl p-4 text-xs leading-relaxed relative ${
                  isUser 
                    ? "bg-[#FF2D8D]/10 border border-[#FF2D8D]/30 text-[#F5DCEB]" 
                    : "bg-[#190C1D]/60 border border-[#4B2342] text-[#F5DCEB] shadow-inner"
                }`}>
                  {/* Subtle visual glow behind AI messages */}
                  {!isUser && idx === 0 && (
                    <div className="absolute top-0 right-0 w-24 h-24 bg-[#FF2D8D]/5 blur-[20px] rounded-full" />
                  )}
                  
                  {/* Format and render Markdown/Paragraphs beautifully */}
                  <div className="space-y-2 whitespace-pre-wrap">
                    {chat.content}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Typing Skeleton */}
          {isAiTyping && (
            <div className="flex gap-4 items-start text-left">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] border border-[#FF2D8D]/40 text-white flex items-center justify-center shadow-[0_0_10px_rgba(255,45,141,0.3)] animate-pulse">
                <Crown size={12} />
              </div>
              <div className="bg-[#190C1D]/60 border border-[#4B2342] rounded-2xl p-4 shadow-inner flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF2D8D] animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF2D8D] animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-[#FF2D8D] animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Chat Input form */}
        <div className="p-4 bg-[#140816] border-t border-[#4B2342]">
          <form onSubmit={handleSend} className="flex gap-3 relative">
            <input 
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Inquire darlings, e.g. 'Can you draft a high-ticket design campaign outline?'"
              className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-2xl pl-4 pr-14 py-3.5 text-xs text-white placeholder-[#D8B7CC]/40 outline-none transition-all focus:shadow-[0_0_15px_rgba(255,45,141,0.15)]"
              id="ai-prompt-input"
            />
            <button 
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white flex items-center justify-center shadow-[0_0_10px_rgba(255,45,141,0.3)] hover:scale-105 transition-transform cursor-pointer"
              id="ai-submit-btn"
            >
              <Send size={14} />
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
