import React, { useState } from "react";
import { useApp } from "../../context/AppContext";
import { Project, Task } from "../../types";
import { 
  Sparkles, Plus, Calendar, Compass, ClipboardList, CheckCircle2, Circle, 
  Trash2, Filter, AlertCircle, ChevronDown, Check, DollarSign, UserCheck 
} from "lucide-react";

export const ProjectsTasksTab: React.FC = () => {
  const { 
    projects, tasks, addProject, addTask, toggleTask, addToast 
  } = useApp();

  // Create Project inputs
  const [showProjForm, setShowProjForm] = useState(false);
  const [projName, setProjName] = useState("");
  const [projClient, setProjClient] = useState("");
  const [projBudget, setProjBudget] = useState("");
  const [projLead, setProjLead] = useState("");

  // Create Task inputs
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [taskTitle, setTaskTitle] = useState("");
  const [taskProjId, setTaskProjId] = useState("");
  const [taskPriority, setTaskPriority] = useState<"High" | "Medium" | "Low">("Medium");
  const [taskAssignee, setTaskAssignee] = useState("");

  // Task filtering state
  const [taskFilter, setTaskFilter] = useState<"All" | "In Progress" | "Completed">("All");

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!projName || !projClient) {
      addToast("Darlings, please fill in Project Name and Client.", "error");
      return;
    }
    await addProject({
      name: projName,
      client: projClient,
      budget: projBudget || "$15,000",
      lead: projLead || "Seraphina Rose",
      progress: 0
    });
    // Clear inputs
    setProjName("");
    setProjClient("");
    setProjBudget("");
    setProjLead("");
    setShowProjForm(false);
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle) {
      addToast("Darlings, please enter a title for your task.", "error");
      return;
    }
    await addTask({
      title: taskTitle,
      projectId: taskProjId || "1",
      priority: taskPriority,
      assignee: taskAssignee || "Giselle Moreau",
      dueDate: new Date().toISOString().split("T")[0]
    });
    setTaskTitle("");
    setTaskAssignee("");
    setShowTaskForm(false);
  };

  // Filtered tasks list
  const filteredTasks = tasks.filter((t) => {
    if (taskFilter === "All") return true;
    return t.status === taskFilter;
  });

  return (
    <div className="space-y-10 text-left" id="projects-tasks-root">
      
      {/* 1. PROJECTS ATELIER */}
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Bespoke Projects Cabinet</h2>
            <p className="text-xs text-[#D8B7CC]">Sculpting premium creative briefs, schedules, and active budgets.</p>
          </div>
          <button 
            onClick={() => setShowProjForm(!showProjForm)}
            className="px-4 py-2.5 rounded-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] hover:scale-105 hover:shadow-[0_0_15px_rgba(255,45,141,0.4)] text-white text-xs font-bold uppercase tracking-widest cursor-pointer transition-all flex items-center gap-2 shadow-[0_0_10px_rgba(255,45,141,0.2)]"
            id="proj-add-btn"
          >
            <Plus size={14} />
            <span>New Bespoke Project</span>
          </button>
        </div>

        {/* Project Creation Form Modal (Glassmorphic Inline) */}
        {showProjForm && (
          <div className="bg-[#2A1830] border-2 border-[#FF2D8D]/30 p-6 rounded-2xl shadow-[0_0_25px_rgba(255,45,141,0.15)] max-w-2xl">
            <h3 className="text-white font-bold text-sm mb-4 uppercase tracking-widest font-sans flex items-center gap-2">
              <Compass className="text-[#FF2D8D] animate-spin" size={16} /> Configure Creative Brief
            </h3>
            <form onSubmit={handleCreateProject} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5 text-left">
                <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Project Master Name</label>
                <input 
                  type="text"
                  required
                  value={projName}
                  onChange={(e) => setProjName(e.target.value)}
                  placeholder="e.g. Elysian Branding Rebirth"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                />
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">VIP Client Name</label>
                <input 
                  type="text"
                  required
                  value={projClient}
                  onChange={(e) => setProjClient(e.target.value)}
                  placeholder="e.g. Moretti Haute Couture"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                />
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Investiture Budget</label>
                <input 
                  type="text"
                  value={projBudget}
                  onChange={(e) => setProjBudget(e.target.value)}
                  placeholder="e.g. $45,000"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                />
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Creative Lead Strategist</label>
                <input 
                  type="text"
                  value={projLead}
                  onChange={(e) => setProjLead(e.target.value)}
                  placeholder="e.g. Seraphina Rose"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                />
              </div>

              <div className="sm:col-span-2 pt-2 flex items-center justify-end gap-3">
                <button 
                  type="button" 
                  onClick={() => setShowProjForm(false)}
                  className="px-4 py-2 text-xs text-[#D8B7CC] hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest shadow-lg cursor-pointer"
                  id="proj-submit-btn"
                >
                  Authorize Project
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Project Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {projects.map((proj) => (
            <div 
              key={proj.id}
              className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 relative overflow-hidden flex flex-col justify-between hover:border-[#FF2D8D]/60 hover:shadow-[0_10px_30px_rgba(255,45,141,0.08)] transition-all"
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[9px] font-mono uppercase tracking-widest text-[#FF5FA8] font-bold bg-[#FF2D8D]/10 px-2 py-0.5 rounded border border-[#FF2D8D]/20">
                      {proj.status}
                    </span>
                    <h3 className="text-white font-bold text-base mt-2.5 leading-tight">{proj.name}</h3>
                  </div>
                </div>

                <div className="space-y-1 text-xs">
                  <p className="text-[#D8B7CC]"><span className="text-[#D8B7CC]/60 font-medium">Client:</span> {proj.client}</p>
                  <p className="text-[#D8B7CC]"><span className="text-[#D8B7CC]/60 font-medium">Creative Director:</span> {proj.lead}</p>
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#D8B7CC]">
                    <span>Atelier Progress</span>
                    <span className="text-white font-bold">{proj.progress}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#130814] rounded-full overflow-hidden border border-[#4B2342]">
                    <div 
                      className="h-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] rounded-full shadow-[0_0_8px_#FF2D8D]"
                      style={{ width: `${proj.progress}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#4B2342]/40 flex items-center justify-between mt-6">
                <div>
                  <span className="text-[9px] font-mono text-[#D8B7CC] uppercase">Noble Value</span>
                  <p className="text-xs font-bold text-white mt-0.5">{proj.budget}</p>
                </div>
                <div className="flex items-center gap-1 text-[10px] text-[#D8B7CC]/80 font-mono">
                  <Calendar size={11} className="text-[#FF2D8D]" />
                  <span>Due: {proj.duedate}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. TASKS WORKBENCH */}
      <div className="space-y-6 pt-6 border-t border-[#4B2342]/40">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Aesthetic Tasks Sprint</h2>
            <p className="text-xs text-[#D8B7CC]">Weekly checkpoints, brand guidelines alignment, and design renders checks.</p>
          </div>
          
          {/* Controls: Add & Filters */}
          <div className="flex items-center gap-4">
            {/* Filters */}
            <div className="flex items-center bg-[#190C1D] border border-[#4B2342] p-1 rounded-xl">
              {(["All", "In Progress", "Completed"] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setTaskFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                    taskFilter === filter 
                      ? "bg-[#2A1830] text-[#FF5FA8] border border-[#5C2A50] shadow-sm" 
                      : "text-[#D8B7CC]/60 hover:text-white"
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>

            <button 
              onClick={() => setShowTaskForm(!showTaskForm)}
              className="p-2.5 rounded-xl bg-[#2A1830] border border-[#4B2342] hover:border-[#FF2D8D] hover:text-white text-[#D8B7CC] transition-all cursor-pointer"
              title="Add task checkpoint"
              id="task-add-btn"
            >
              <Plus size={16} />
            </button>
          </div>
        </div>

        {/* Task Creation Form Card Inline */}
        {showTaskForm && (
          <div className="bg-[#2A1830] border border-[#5C2A50] p-5 rounded-2xl shadow-xl max-w-xl text-left">
            <h3 className="text-white font-bold text-xs mb-3 uppercase tracking-widest font-mono">Queue Sprint Checkpoint</h3>
            <form onSubmit={handleCreateTask} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2 space-y-1.5">
                <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Task Title / Brief</label>
                <input 
                  type="text"
                  required
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  placeholder="e.g. Refine silk brand guidelines"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3.5 py-2.5 text-xs text-white outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Priority Status</label>
                <select 
                  value={taskPriority}
                  onChange={(e) => setTaskPriority(e.target.value as any)}
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3 py-2 text-xs text-[#D8B7CC] outline-none"
                >
                  <option value="High">High Luxury Priority</option>
                  <option value="Medium">Medium Priority</option>
                  <option value="Low">Low Priority</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Assignee Scholar</label>
                <input 
                  type="text"
                  value={taskAssignee}
                  onChange={(e) => setTaskAssignee(e.target.value)}
                  placeholder="e.g. Giselle Moreau"
                  className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-3 py-2 text-xs text-white outline-none"
                />
              </div>

              <div className="sm:col-span-2 pt-2 flex items-center justify-end gap-2">
                <button 
                  type="button" 
                  onClick={() => setShowTaskForm(false)}
                  className="px-3 py-1.5 text-xs text-[#D8B7CC]"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest"
                >
                  Queue Task
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Tasks Checklist Grid */}
        <div className="bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl space-y-3.5">
          {filteredTasks.map((task) => {
            const isCompleted = task.status === "Completed";
            return (
              <div 
                key={task.id}
                className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                  isCompleted 
                    ? "bg-[#190C1D]/30 border-transparent opacity-60" 
                    : "bg-[#190C1D]/60 border-[#4B2342] hover:border-[#FF2D8D]/40"
                }`}
              >
                <div className="flex items-center gap-4 text-left min-w-0">
                  {/* Interactive toggle circle */}
                  <button 
                    onClick={() => toggleTask(task.id)}
                    className="text-[#D8B7CC] hover:text-[#FF2D8D] transition-all cursor-pointer shrink-0"
                    id={`task-toggle-${task.id}`}
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="text-[#FF2D8D]" size={20} />
                    ) : (
                      <Circle size={20} />
                    )}
                  </button>
                  <div className="min-w-0">
                    <p className={`text-xs font-semibold truncate ${
                      isCompleted ? "line-through text-[#D8B7CC]/60" : "text-white"
                    }`}>
                      {task.title}
                    </p>
                    <div className="flex items-center gap-2.5 mt-1 text-[10px] font-mono text-[#D8B7CC]/70">
                      <span className="flex items-center gap-1 text-[#FF5FA8]">
                        <UserCheck size={10} /> {task.assignee}
                      </span>
                      <span>·</span>
                      <span className={`px-1.5 py-0.2 rounded font-bold uppercase tracking-wider text-[8px] ${
                        task.priority === "High" 
                          ? "bg-[#FF2D8D]/15 text-[#FF2D8D]" 
                          : task.priority === "Medium"
                            ? "bg-[#FF78C5]/15 text-[#FF78C5]"
                            : "bg-[#4B2342] text-[#D8B7CC]"
                      }`}>
                        {task.priority} Priority
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-right shrink-0 ml-4">
                  <span className="text-[10px] text-[#D8B7CC]/60 font-mono">Sprint Target</span>
                  <p className="text-xs text-[#D8B7CC] font-mono font-medium mt-0.5">{task.dueDate}</p>
                </div>
              </div>
            );
          })}

          {filteredTasks.length === 0 && (
            <div className="text-center py-10 text-xs text-[#D8B7CC]/50 font-mono flex flex-col items-center justify-center gap-2">
              <ClipboardList size={24} className="opacity-40" />
              <span>Darlings, no sprint checks are pending here. Beautiful!</span>
            </div>
          )}
        </div>
      </div>

    </div>
  );
};
