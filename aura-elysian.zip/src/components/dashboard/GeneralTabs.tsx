import React, { useState } from "react";
import { useApp } from "../../context/AppContext";
import { 
  Calendar as CalendarIcon, MessageSquare, Send, Sparkles, FileText, Download, 
  Trash2, Layers, Key, Shield, Eye, EyeOff, Globe, Bell, Heart, Plus, BadgeAlert 
} from "lucide-react";

// ==========================================
// 1. CALENDAR SCHEDULER
// ==========================================
export const CalendarTab: React.FC = () => {
  const [bookings, setBookings] = useState([
    { id: "1", client: "Moretti Haute Couture", title: "Silk Palette Consultation", time: "10:00 AM - 11:30 AM", type: "Visual Strategy" },
    { id: "2", client: "Maison Dupond Perfumerie", title: "Quiz Architecture Review", time: "01:00 PM - 02:30 PM", type: "Atelier Review" },
    { id: "3", client: "Thorne Aesthetic Clinic", title: "Automated SMS Integration", time: "04:00 PM - 05:00 PM", type: "CRM Technical Check" }
  ]);

  const days = Array.from({ length: 30 }, (_, i) => i + 1);

  return (
    <div className="space-y-8 text-left" id="calendar-tab-root">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">Luxury Booking Calendar</h2>
        <p className="text-xs text-[#D8B7CC]">Schedule consultations, creative sprints, and VIP launches.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Month grid */}
        <div className="lg:col-span-8 bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl">
          <div className="flex items-center justify-between pb-4 border-b border-[#4B2342] mb-6">
            <span className="text-sm font-bold text-white uppercase font-sans">July 2026</span>
            <span className="text-xs text-[#FF5FA8] font-mono">Month View</span>
          </div>

          <div className="grid grid-cols-7 gap-2.5 text-center">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <span key={day} className="text-[10px] font-mono uppercase tracking-widest text-[#D8B7CC]/60 font-bold py-1">
                {day}
              </span>
            ))}
            
            {/* Blank offsets */}
            <div className="p-3" />
            <div className="p-3" />
            <div className="p-3" />

            {days.map((day) => {
              const hasBooking = day === 1 || day === 5 || day === 15;
              return (
                <button 
                  key={day}
                  className={`p-3 rounded-xl text-xs font-semibold font-mono relative transition-all cursor-pointer ${
                    day === 1 
                      ? "bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] text-white shadow-[0_0_12px_rgba(255,45,141,0.4)]" 
                      : hasBooking
                        ? "bg-[#311B37] text-[#FF5FA8] border border-[#5C2A50]"
                        : "bg-[#190C1D]/60 text-[#D8B7CC] hover:bg-[#311B37]/30 border border-transparent"
                  }`}
                >
                  <span>{day}</span>
                  {hasBooking && day !== 1 && (
                    <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[#FF2D8D] shadow-[0_0_4px_#FF2D8D]" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Schedule panel */}
        <div className="lg:col-span-4 bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl flex flex-col justify-between">
          <div className="space-y-6">
            <h3 className="text-white font-bold text-sm uppercase tracking-widest font-mono">Today's Roster</h3>
            
            <div className="space-y-4">
              {bookings.map((b) => (
                <div key={b.id} className="p-4 rounded-2xl bg-[#190C1D]/60 border border-[#4B2342] hover:border-[#FF2D8D]/40 transition-colors text-left">
                  <span className="text-[9px] font-mono uppercase font-bold text-[#FF5FA8]">{b.type}</span>
                  <h4 className="text-white font-bold text-xs mt-1">{b.title}</h4>
                  <p className="text-[10px] text-[#D8B7CC] mt-0.5">{b.client}</p>
                  <p className="text-[10px] text-[#D8B7CC]/60 mt-2 font-mono">{b.time}</p>
                </div>
              ))}
            </div>
          </div>

          <button className="w-full py-3 rounded-xl bg-[#130814] hover:bg-[#311B37] text-white border border-[#4B2342] hover:border-[#FF2D8D] text-xs font-bold uppercase tracking-widest transition-all mt-6 cursor-pointer">
            Reserve Consult Slot
          </button>
        </div>
      </div>
    </div>
  );
};


// ==========================================
// 2. LUXE TEAM CHAT ROOM
// ==========================================
export const MessagesTab: React.FC = () => {
  const { messages, sendTeamMessage, addToast } = useApp();
  const [msgInput, setMsgInput] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!msgInput.trim()) return;
    const txt = msgInput;
    setMsgInput("");
    await sendTeamMessage(txt);
  };

  return (
    <div className="h-[calc(100vh-12rem)] bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] shadow-2xl flex flex-col justify-between overflow-hidden text-left" id="messages-tab-root">
      
      {/* Thread Header */}
      <div className="p-5 bg-[#190C1D] border-b border-[#4B2342] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center text-white font-bold">
            <MessageSquare size={16} />
          </div>
          <div>
            <h3 className="text-white font-bold text-sm">Elysian Creative Atelier</h3>
            <p className="text-[10px] text-[#D8B7CC]">Collaborative design channels & assets reviews.</p>
          </div>
        </div>
        <span className="text-[10px] font-mono text-[#FF5FA8] uppercase font-bold">3 active designers</span>
      </div>

      {/* Message Ledger */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin scrollbar-thumb-[#4B2342]">
        {messages.map((m) => (
          <div key={m.id} className="flex gap-4 items-start text-left">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center text-white font-bold text-xs shrink-0 border border-[#4B2342]">
              {m.avatar}
            </div>
            <div className="min-w-0 bg-[#190C1D]/60 border border-[#4B2342] p-3 rounded-2xl">
              <div className="flex items-baseline gap-2">
                <span className="text-white font-bold text-xs">{m.sender}</span>
                <span className="text-[9px] uppercase font-mono tracking-widest text-[#FF78C5]">{m.role}</span>
                <span className="text-[8px] text-[#D8B7CC]/60 font-mono">{m.time}</span>
              </div>
              <p className="text-xs text-[#F5DCEB] mt-1.5 leading-relaxed">{m.content}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 bg-[#140816] border-t border-[#4B2342]">
        <form onSubmit={handleSubmit} className="flex gap-3 relative">
          <input 
            type="text"
            value={msgInput}
            onChange={(e) => setMsgInput(e.target.value)}
            placeholder="Broadcast creative brief to team..."
            className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-2xl pl-4 pr-14 py-3.5 text-xs text-white placeholder-[#D8B7CC]/30 outline-none transition-all"
          />
          <button 
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white flex items-center justify-center shadow-md cursor-pointer hover:scale-105 transition-transform"
          >
            <Send size={14} />
          </button>
        </form>
      </div>

    </div>
  );
};


// ==========================================
// 3. DOCUMENTS CABINET
// ==========================================
export const DocumentsTab: React.FC = () => {
  const { addToast } = useApp();
  const docs = [
    { name: "maison_dupond_brand_book_2026.pdf", size: "14.2 MB", desc: "High-resolution typography guide & silk paper print palettes.", category: "Branding" },
    { name: "haute_couture_moretti_invoice_spec.xlsx", size: "4.8 MB", desc: "Financial billing estimations and commission ledger specifications.", category: "Finance" },
    { name: "thorne_aesthetic_sms_flows.json", size: "120 KB", desc: "Configuration flows for automatic CRM appointment check-ins.", category: "Integrations" }
  ];

  const handleDownload = (name: string) => {
    addToast(`Downloading luxurious asset: ${name}`, "success");
  };

  return (
    <div className="space-y-8 text-left animate-fade-in" id="documents-tab-root">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">VIP Documents Vault</h2>
        <p className="text-xs text-[#D8B7CC]">Vault of creative guidelines, high-profile brief sheets, and financial Excel spreadsheets.</p>
      </div>

      <div className="bg-[#2A1830]/40 backdrop-blur-xl border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl space-y-4">
        {docs.map((doc, idx) => (
          <div key={idx} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#190C1D]/60 border border-[#4B2342] hover:border-[#FF2D8D]/40 transition-colors text-left">
            <div className="flex items-start gap-3.5 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-[#311B37] border border-[#5C2A50] flex items-center justify-center text-[#FF2D8D] shrink-0">
                <FileText size={18} />
              </div>
              <div className="min-w-0">
                <span className="text-[9px] font-mono uppercase tracking-widest text-[#FF5FA8] font-bold">{doc.category}</span>
                <h4 className="text-white font-bold text-xs mt-0.5 truncate">{doc.name}</h4>
                <p className="text-[11px] text-[#D8B7CC] mt-1 leading-relaxed">{doc.desc}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 shrink-0">
              <span className="text-[10px] font-mono text-[#D8B7CC]/60">{doc.size}</span>
              <button 
                onClick={() => handleDownload(doc.name)}
                className="p-2 bg-[#2A1830] hover:bg-[#311B37] border border-[#4B2342] hover:border-[#FF2D8D] text-[#D8B7CC] hover:text-white rounded-xl transition-all cursor-pointer"
                title="Download assets safely"
              >
                <Download size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};


// ==========================================
// 4. TEAM ROSTER DIRECTORY
// ==========================================
export const TeamTab: React.FC = () => {
  const team = [
    { name: "Seraphina Rose", role: "Elite Brand Strategist", mail: "s.rose@auraelysian.com", avatar: "SR", quote: "Simplicity is the ultimate design luxury, darlings." },
    { name: "Anouk Dubois", role: "Creative Designer", mail: "a.dubois@auraelysian.com", avatar: "AD", quote: "Glassmorphism bridges structural code with visual velvet." },
    { name: "Giselle Moreau", role: "SaaS Product Designer", mail: "g.moreau@auraelysian.com", avatar: "GM", quote: "Clean alignment matches bulletproof backend trace security." }
  ];

  return (
    <div className="space-y-8 text-left" id="team-tab-root">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">Luxe Team Atelier</h2>
        <p className="text-xs text-[#D8B7CC]">A cohesive roster of high-society strategists, designers, and web developers.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {team.map((t, idx) => (
          <div key={idx} className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 hover:border-[#FF2D8D]/60 hover:shadow-2xl transition-all relative overflow-hidden text-center">
            <div className="absolute top-0 right-0 w-20 h-20 bg-[#FF2D8D]/5 blur-[25px] rounded-full" />
            
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#FF2D8D] to-[#FF78C5] flex items-center justify-center font-bold text-lg text-white mx-auto border-2 border-[#5C2A50] shadow-md">
              {t.avatar}
            </div>

            <h3 className="text-white font-extrabold text-base mt-4 leading-tight">{t.name}</h3>
            <p className="text-[10px] font-mono uppercase tracking-widest text-[#FF5FA8] font-bold mt-1">{t.role}</p>
            <p className="text-[10px] text-[#D8B7CC]/60 mt-0.5">{t.mail}</p>

            <p className="text-xs italic text-[#D8B7CC] mt-6 leading-relaxed border-t border-[#4B2342]/40 pt-4">
              "{t.quote}"
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};


// ==========================================
// 5. PROFILE MANAGER
// ==========================================
export const ProfileTab: React.FC = () => {
  const { currentUser, addToast } = useApp();
  const [profileForm, setProfileForm] = useState({
    name: currentUser?.name || "Taimi A.",
    email: currentUser?.email || "taimiahome@gmail.com",
    company: currentUser?.company || "Elysian Atelier",
    tier: currentUser?.tier || "Elite Diamond Concierge"
  });

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    addToast("Profile parameters updated beautifully, darlings.", "success");
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 text-left animate-fade-in" id="profile-tab-root">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">Honored Profile Parameters</h2>
        <p className="text-xs text-[#D8B7CC]">Review your membership tier, company configurations, and secure access.</p>
      </div>

      <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#FF2D8D]/5 blur-[35px] rounded-full" />
        
        <form onSubmit={handleUpdate} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Patron Name</label>
              <input 
                type="text"
                required
                value={profileForm.name}
                onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Patron Email</label>
              <input 
                type="email"
                disabled
                value={profileForm.email}
                className="w-full bg-[#130814]/50 border border-[#4B2342] rounded-xl px-4 py-2.5 text-xs text-[#D8B7CC]/60 outline-none cursor-not-allowed"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Maison Company</label>
              <input 
                type="text"
                value={profileForm.company}
                onChange={(e) => setProfileForm({ ...profileForm, company: e.target.value })}
                className="w-full bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC] font-bold">Membership Tier Active</label>
              <input 
                type="text"
                disabled
                value={profileForm.tier}
                className="w-full bg-[#130814]/50 border border-[#4B2342] rounded-xl px-4 py-2.5 text-xs text-[#FF5FA8] font-bold outline-none cursor-not-allowed"
              />
            </div>
          </div>

          <button 
            type="submit"
            className="px-6 py-3 rounded-full bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest hover:scale-105 transition-transform shadow-md cursor-pointer"
          >
            Update Suite Parameters
          </button>
        </form>
      </div>
    </div>
  );
};


// ==========================================
// 6. SETTINGS & SECURITY & API KEYS
// ==========================================
export const SettingsTab: React.FC = () => {
  const { apiKeys, generateApiKey, addToast } = useApp();
  
  // Local states
  const [activeSettingsSub, setActiveSettingsSub] = useState<"security" | "keys" | "integrations">("keys");
  const [keyName, setKeyName] = useState("");
  const [showReveal, setShowReveal] = useState<Record<string, boolean>>({});

  const handleCreateToken = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyName) return;
    await generateApiKey(keyName);
    setKeyName("");
  };

  const integrations = [
    { name: "Stripe Express Gateway", status: "Active Connected", desc: "Configures automatic client billing, invoices matching, and payment deposits." },
    { name: "Google Sovereign OAuth", status: "Active Connected", desc: "Verifies users, manages session encryption, and secures administrator pathways." },
    { name: "Gemini Strategy Engine API", status: "Active Authorized", desc: "Powers Aura Concierge strategy recommendations and copywriter modules." }
  ];

  return (
    <div className="space-y-8 text-left animate-fade-in" id="settings-tab-root">
      
      {/* Settings Sub nav */}
      <div className="flex items-center gap-3 border-b border-[#4B2342] pb-4">
        <button
          onClick={() => setActiveSettingsSub("security")}
          className={`px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
            activeSettingsSub === "security" 
              ? "bg-[#2A1830] text-[#FF5FA8] border border-[#5C2A50]" 
              : "text-[#D8B7CC]/60 hover:text-white"
          }`}
        >
          <Shield size={13} />
          <span>Security & SSL</span>
        </button>
        <button
          onClick={() => setActiveSettingsSub("keys")}
          className={`px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
            activeSettingsSub === "keys" 
              ? "bg-[#2A1830] text-[#FF5FA8] border border-[#5C2A50]" 
              : "text-[#D8B7CC]/60 hover:text-white"
          }`}
          id="settings-apikeys-btn"
        >
          <Key size={13} />
          <span>API Access Keys</span>
        </button>
        <button
          onClick={() => setActiveSettingsSub("integrations")}
          className={`px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer flex items-center gap-2 ${
            activeSettingsSub === "integrations" 
              ? "bg-[#2A1830] text-[#FF5FA8] border border-[#5C2A50]" 
              : "text-[#D8B7CC]/60 hover:text-white"
          }`}
        >
          <Layers size={13} />
          <span>Integrations Atelier</span>
        </button>
      </div>

      {/* --- SUBVIEW: SECURITY --- */}
      {activeSettingsSub === "security" && (
        <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl space-y-6">
          <div className="text-left">
            <h3 className="text-white font-bold text-sm">Suite Security Charter</h3>
            <p className="text-xs text-[#D8B7CC]">Your suite operates with sovereign AES-256 SSL encryption. Check configuration status.</p>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-[#190C1D]/60 border border-[#4B2342] rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">Sovereign SSL Protection</span>
                <span className="text-[10px] text-[#D8B7CC]/75 font-mono">TLS 1.3 Active Cipher</span>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-[9px] uppercase font-bold tracking-widest border border-emerald-500/20">Active Safe</span>
            </div>

            <div className="p-4 bg-[#190C1D]/60 border border-[#4B2342] rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-white block">Google Auth Session Protection</span>
                <span className="text-[10px] text-[#D8B7CC]/75 font-mono">JWT Verified Signature</span>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-[9px] uppercase font-bold tracking-widest border border-emerald-500/20">Active Safe</span>
            </div>
          </div>
        </div>
      )}

      {/* --- SUBVIEW: API ACCESS KEYS --- */}
      {activeSettingsSub === "keys" && (
        <div className="space-y-6">
          <div className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 shadow-2xl text-left space-y-6">
            <div>
              <h3 className="text-white font-bold text-sm">Suite Webhook & API Keys</h3>
              <p className="text-xs text-[#D8B7CC]">Generate secure API credentials to query leads, contracts, or invoicing systems externally.</p>
            </div>

            {/* Create Key form */}
            <form onSubmit={handleCreateToken} className="flex flex-col sm:flex-row gap-3">
              <input 
                type="text"
                required
                value={keyName}
                onChange={(e) => setKeyName(e.target.value)}
                placeholder="e.g. Aura Live Strategy Production"
                className="flex-1 bg-[#130814] border border-[#4B2342] focus:border-[#FF2D8D] rounded-xl px-4 py-2.5 text-xs text-white outline-none"
                id="settings-keyname-input"
              />
              <button 
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#FF2D8D] to-[#FF78C5] text-white text-xs font-bold uppercase tracking-widest cursor-pointer shadow-md hover:scale-102 transition-transform shrink-0"
                id="settings-key-submit"
              >
                Generate Production Key
              </button>
            </form>

            {/* Keys Table */}
            <div className="bg-[#190C1D]/60 border border-[#4B2342] rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-[#4B2342] bg-[#190C1D] text-[9px] uppercase font-mono tracking-widest text-[#D8B7CC]">
                      <th className="p-3 pl-4">Key Name</th>
                      <th className="p-3">Permissions Scope</th>
                      <th className="p-3">DISPATCHED DATE</th>
                      <th className="p-3">Confidential Token</th>
                      <th className="p-3 pr-4 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="text-xs divide-y divide-[#4B2342]/40">
                    {apiKeys.map((k) => (
                      <tr key={k.id} className="hover:bg-[#2A1830]/50 transition-colors">
                        <td className="p-3 pl-4 font-semibold text-white">{k.name}</td>
                        <td className="p-3 text-[#D8B7CC]">{k.permissions}</td>
                        <td className="p-3 text-[#D8B7CC]/75 font-mono">{k.created}</td>
                        <td className="p-3 font-mono">
                          <div className="flex items-center gap-2">
                            <span>{showReveal[k.id] ? "aur_live_49f8a847d89028a" : k.prefix}</span>
                            <button 
                              onClick={() => setShowReveal({ ...showReveal, [k.id]: !showReveal[k.id] })}
                              className="text-[#FF5FA8] hover:text-white transition-colors"
                            >
                              {showReveal[k.id] ? <EyeOff size={11} /> : <Eye size={11} />}
                            </button>
                          </div>
                        </td>
                        <td className="p-3 pr-4 text-right">
                          <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-[8px] uppercase font-bold border border-emerald-500/20">
                            {k.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- SUBVIEW: INTEGRATIONS --- */}
      {activeSettingsSub === "integrations" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {integrations.map((item, idx) => (
              <div key={idx} className="bg-[#2A1830]/50 backdrop-blur-lg border border-[#5C2A50] rounded-[2.5rem] p-6 text-left relative flex flex-col justify-between">
                <div className="space-y-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-[#FF5FA8] font-bold bg-[#FF2D8D]/10 px-2 py-0.5 rounded border border-[#FF2D8D]/20">
                      {item.status}
                    </span>
                  </div>
                  <h4 className="text-white font-bold text-sm leading-tight">{item.name}</h4>
                  <p className="text-xs text-[#D8B7CC] leading-relaxed">{item.desc}</p>
                </div>

                <button 
                  onClick={() => addToast(`Integrating premium configurations for ${item.name}`, "info")}
                  className="w-full py-2 bg-[#130814] hover:bg-[#311B37] text-white border border-[#4B2342] hover:border-[#FF2D8D] text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all mt-6"
                >
                  Configure connection
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
