import React from "react";
import { AppProvider, useApp } from "./context/AppContext";
import { Sidebar } from "./components/Sidebar";
import { Header } from "./components/Header";
import { LandingPage } from "./components/LandingPage";
import { AuthScreens } from "./components/AuthScreens";
import { DashboardContent } from "./components/DashboardContent";
import { CheckCircle, Info, AlertTriangle, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const AppContent: React.FC = () => {
  const { currentUser, currentView, toasts, removeToast } = useApp();

  // Authentication & Guest Routing
  const isAuthView = ["login", "signup", "forgot-password", "verify"].includes(currentView);

  if (!currentUser) {
    if (isAuthView) {
      return <AuthScreens />;
    }
    return <LandingPage />;
  }

  // Logged-In Luxury Portal Routing
  return (
    <div className="min-h-screen bg-[#130814] flex text-[#F5DCEB] relative overflow-hidden font-sans" id="app-portal-layout">
      
      {/* Background ambient light blobs */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] bg-[#FF2D8D] opacity-10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-150px] left-[-50px] w-[600px] h-[600px] bg-[#5C2A50] opacity-20 rounded-full blur-[150px]" />
      </div>

      {/* Main Collapsible Sidebar */}
      <Sidebar />

      {/* Primary content board */}
      <div className="flex-1 flex flex-col min-w-0 relative z-10 h-screen overflow-hidden">
        
        {/* Main Header */}
        <Header />

        {/* Scrollable Dashboard view */}
        <main className="flex-1 overflow-y-auto p-6 lg:p-8 scrollbar-thin scrollbar-thumb-[#4B2342] scrollbar-track-transparent">
          <div className="max-w-7xl mx-auto w-full h-full">
            <DashboardContent />
          </div>
        </main>
      </div>

      {/* Global Luxury Toast Notifications Drawer */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-sm w-full pointer-events-none" id="global-toasts-drawer">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="pointer-events-auto w-full bg-[#2A1830]/95 backdrop-blur-md border border-[#5C2A50] rounded-2xl p-4 shadow-[0_10px_30px_rgba(0,0,0,0.5)] flex items-start gap-3.5 relative overflow-hidden group"
            >
              {/* Left dynamic color indicator */}
              <div className={`absolute top-0 bottom-0 left-0 w-1.5 ${
                toast.type === "success" 
                  ? "bg-emerald-500" 
                  : toast.type === "error" 
                    ? "bg-rose-500" 
                    : "bg-[#FF2D8D]"
              }`} />

              <div className="shrink-0 mt-0.5">
                {toast.type === "success" && <CheckCircle className="text-emerald-400" size={16} />}
                {toast.type === "error" && <AlertTriangle className="text-rose-400" size={16} />}
                {toast.type === "info" && <Info className="text-[#FF2D8D]" size={16} />}
              </div>

              <div className="flex-1 text-left">
                <p className="text-xs font-semibold text-white leading-relaxed">{toast.message}</p>
                <span className="text-[9px] font-mono uppercase tracking-widest text-[#D8B7CC]/60 block mt-1">Aura Notification</span>
              </div>

              <button 
                onClick={() => removeToast(toast.id)}
                className="shrink-0 text-[#D8B7CC]/50 hover:text-white transition-colors cursor-pointer"
              >
                <X size={14} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
